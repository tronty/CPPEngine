## @package python_image_code Contains documentation this library.
##
## @mainpage Python Image Code
##
## Contains functions for image processing 
## The code can be downloaded from http://code-spot.co.za/python-image-code/.
##
## @version 0.6 (last updated 15 February 2010)
## @author Herman Tulleken (herman.tulleken@gmail.com)
##
