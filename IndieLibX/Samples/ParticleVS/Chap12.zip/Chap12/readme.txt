Chapter 12 (Chap12\):
Particles. Watch how three different particle systems are put to good use in this demo.
ParticlesVS. Same as last, this time with vertex shaders.
 
