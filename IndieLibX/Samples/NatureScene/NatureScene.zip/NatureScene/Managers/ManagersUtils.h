#ifndef MANAGERS_H
#define MANAGERS_H

#include "MediaPathManager.h"
#include "GeometryManager.h"
#include "TexturesManager.h"
#include "WindowsManager.h"

#endif