#ifndef APP_ICNLUDES_H
#define APP_INCLUDES_H

#include "TextureCoordGenerator.h"
#include "Appearance.h"
#include "Material.h"
#include "Texture.h"
#include "Light.h"

#endif