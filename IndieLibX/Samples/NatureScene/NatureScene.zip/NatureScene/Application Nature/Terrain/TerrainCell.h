#ifndef TERRAIN_CELL_H
#define TERRAIN_CELL_H

#include "TerrainUtils.h"
#include "HeightMap.h"

#ifndef OFFSET
  #define OFFSET(x) ((char *)NULL+(x))
#endif

typedef struct terrainVertex
{
  Tuple2f uv;
  Tuple3f normal,
          vertex;
} TVertex;

class TerrainCell
{
  public:
    TerrainCell();
   ~TerrainCell();

    bool  setup(const HeightMap& heightMap,
                const Tuple2i&   start);
   
    const unsigned int  getGeometryBufferID() const;
    const Tuple2f      &getVerticalBounds();
    const bool          render();

    static const unsigned short *getIndexStream();
    static const unsigned int    getIndexBufferID();
    static void                  setupIndices(bool compile);

  private:
    unsigned int     geometryBufferID;
    Tuple2f          verticalBounds;

    static unsigned int   userCount;
    static unsigned int   indexBufferID;
    static unsigned short indices[INDEX_COUNT];
};

#endif
