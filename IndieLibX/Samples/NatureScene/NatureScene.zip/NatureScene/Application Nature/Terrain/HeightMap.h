#ifndef HEIGHT_MAP_H
#define HEIGHT_MAP_H

#include "TerrainUtils.h"

typedef struct heightmapVertex
{
  Tuple2f uv;
  Tuple3f binormal,
          tangent,
          normal,
          vertex;
} HMVertex;

class HeightMap
{
  public:
    HeightMap();
   ~HeightMap();

    bool  setup(const Image&  heightmap,
                const Image&  watermap);
     
    const HMVertex *getVertexStream()  const;
    
    bool  buildWeightMap(Image & image);
    const float getInterpolatedHeight(const Tuple3f &location) const;
    const int   getIndexCount() const;
    const int   getHeight()     const;
    const int   getWidth()      const;
    bool render();

  private:
    HMVertex *vertices;
    void      computeBTangents();
    int       indexCount, 
              height,
              width;
};

#endif
