#include "GrassCell.h"

GrassCell::GrassCell()
{
  geometryBufferID =         0;
  verticalBounds.x =  10000.0f;
  verticalBounds.y = -10000.0f;
  indexBufferID    =         0;
  blockCount       =         0;
  indexCount       =         0;
  indices          =      NULL;
}

GrassCell::~GrassCell()
{
  if(geometryBufferID)
    glDeleteBuffersARB(1, &geometryBufferID);

  if(indexBufferID)
    glDeleteBuffersARB(1, &indexBufferID);

  deleteArray(indices);
}


const bool GrassCell::render()
{
  static int offset1 = sizeof(Tuple3f),
             offset2 = sizeof(Tuple3f) + offset1,
             offset3 = sizeof(Tuple3f) + offset2,
             offset4 = sizeof(Tuple3f) + offset3,
             offset5 = sizeof(Tuple3f) + offset4;

  if(!blockCount || !indexCount || !geometryBufferID)
    return false;

  if(geometryBufferID)
  {
    glBindBufferARB(GL_ARRAY_BUFFER_ARB, geometryBufferID); 

    glClientActiveTextureARB(GL_TEXTURE0_ARB);
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);
    glTexCoordPointer(3, GL_FLOAT, sizeof(GVertex), OFFSET(0));
 
    glClientActiveTextureARB(GL_TEXTURE1_ARB);
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);
    glTexCoordPointer(3, GL_FLOAT, sizeof(GVertex), OFFSET(offset1));

    glClientActiveTextureARB(GL_TEXTURE2_ARB);
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);
    glTexCoordPointer(3, GL_FLOAT, sizeof(GVertex), OFFSET(offset2));

    glClientActiveTextureARB(GL_TEXTURE3_ARB);
    glEnableClientState(GL_TEXTURE_COORD_ARRAY);
    glTexCoordPointer(3, GL_FLOAT, sizeof(GVertex), OFFSET(offset3));

    glNormalPointer(GL_FLOAT, sizeof(GVertex), OFFSET(offset4));
    glEnableClientState(GL_NORMAL_ARRAY);
 
    glVertexPointer(3, GL_FLOAT, sizeof(GVertex), OFFSET(offset5));
    glEnableClientState(GL_VERTEX_ARRAY);
  }

  if(indexBufferID)
  {
    glBindBufferARB(GL_ELEMENT_ARRAY_BUFFER_ARB, indexBufferID);
    glDrawElements(GL_TRIANGLES, indexCount, GL_UNSIGNED_SHORT,  0);
    glBindBufferARB(GL_ELEMENT_ARRAY_BUFFER_ARB, 0);
  }
  else
    glDrawRangeElements(GL_TRIANGLES, 0, indexCount, indexCount, GL_UNSIGNED_SHORT, indices);

  if(geometryBufferID)
  {
    glBindBufferARB(GL_ARRAY_BUFFER_ARB, 0); 

    glDisableClientState(GL_TEXTURE_COORD_ARRAY);
    glDisableClientState(GL_VERTEX_ARRAY);
    glDisableClientState(GL_NORMAL_ARRAY);
  }
  return true;
}

bool  GrassCell::setup(const HeightMap &distribution,
                       const Tuple2i   &offset,
                       const Image     &randommap,
				               const Image     &coveragemap)
{
  const HMVertex *vertices       = distribution.getVertexStream();
  GrassBlock     *grass          = NULL;

  const int       skipX          = 1,
                  skipY          = 1;

  Matrix4f        yRandRotation;
  Tuple4f         texCoordinate,
                  random;

  Tuple3f         vertexOffset;

  const  GLubyte *coverageContent = coveragemap.getDataBuffer(),
	               *randomContent   = randommap.getDataBuffer();
  float           randHeight      = 0,
                  jitter          = 0;

  bool            status          = true;

  int             indicesCounter  = 0,
                  indexOffset     = 0,
                  nextGObject     = 0,
                  components      = randommap.getComponentsCount(),
				          cComponents     = coveragemap.getComponentsCount(),
                  height          = randommap.getHeight(),
                  width           = randommap.getWidth(),
                  index           = 0,
                  i0              = 0,
                  y               = 0,
                  x               = 0;

  if(!randomContent || !coverageContent)
    return Logger::writeErrorLog("Null randommap || coveragemap");

  if(!(height == HEIGHT_MAP_DEPTH) || !(width == HEIGHT_MAP_WIDTH) || (components != 4))
    return Logger::writeErrorLog("Randommap has unexpected width, height or components count (must be 4x256x256)");

  for(y = 0, index = 0; y < TILE_ROW_COUNT - 1; y+=skipY)
  {
    for(x = 0; x < TILE_COLUMN_COUNT - 1; x+=skipX)
    {
      index = (y + offset.y)*distribution.getWidth() + offset.x + x;

      if((vertices[index].vertex.y > GRASS_LOWER_THRESHOLD) &&
         (vertices[index].vertex.y < GRASS_UPPER_THRESHOLD))
        indicesCounter++;
    }
  } 

  if(indicesCounter <= 0)
    return true;

  blockCount = indicesCounter;
  indexCount = indicesCounter * 18;

  indicesCounter = 0;
  indices        = new unsigned short[indexCount];

  glGenBuffersARB(1, &geometryBufferID);
    
  glBindBufferARB(GL_ARRAY_BUFFER_ARB, geometryBufferID);
  glBufferDataARB(GL_ARRAY_BUFFER_ARB, blockCount * sizeof(GrassBlock),
                  NULL, GL_STATIC_DRAW_ARB);

  if(glGetError() == GL_NO_ERROR)
    grass = (GrassBlock *)glMapBufferARB(GL_ARRAY_BUFFER_ARB, GL_WRITE_ONLY_ARB);
  else
   return Logger::writeErrorLog("Not enough memory for the interleaved geometry arrays");

  if(!status)
  {
    return Logger::writeErrorLog("Could not generate a geometry buffer object, GRASS");
  }

  for(y = 0, index = 0; y < TILE_ROW_COUNT - 1; y+=skipY)
  {
    for(x = 0; x < TILE_COLUMN_COUNT - 1; x+=skipX)
    {
      index = (y + offset.y)*distribution.getWidth() + offset.x + x;

      random.set(float(randomContent[index*4 + 0])/255.0f,
                 float(randomContent[index*4 + 1])/255.0f,
                 float(randomContent[index*4 + 2])/255.0f,
                 float(randomContent[index*4 + 3])/255.0f);

      vertexOffset = vertices[index].vertex;
      if((vertexOffset.y > GRASS_LOWER_THRESHOLD) &&
         (vertexOffset.y < GRASS_UPPER_THRESHOLD))
      {
        texCoordinate.set(0.0f, 0.0f, 0.25f, 1.0f);

        vertexOffset.x  += (random.x - 0.5f)*TERRAIN_WIDTH_SCALE;
        vertexOffset.z  += (random.y - 0.5f)*TERRAIN_DEPTH_SCALE;
        indexOffset      = 12*nextGObject;
        randHeight       = GRASS_HEIGHT + random.z*GRASS_HEIGHT_OFFSET;
        random.w         = float(coverageContent[index*cComponents+ 0])/255.0f;
        jitter           = clamp(random.w, 0.2f, 1.0f);
        vertexOffset.y   = distribution.getInterpolatedHeight(vertexOffset) - 2.0f;

        verticalBounds.x =      vertexOffset.y           < verticalBounds.x ?         vertexOffset.y        : verticalBounds.x;
        verticalBounds.y = (vertexOffset.y + randHeight) > verticalBounds.y ? (vertexOffset.y + randHeight) : verticalBounds.y;

        if( random.w > 0.25 &&  random.w <= 0.5)
        {
          texCoordinate.x += 0.25;
          texCoordinate.z += 0.25;
        }

        if( random.w > 0.5 &&  random.w <= 0.75)
        {
          texCoordinate.x += 0.5;
          texCoordinate.z += 0.5;
        }
        
        if( random.w > 0.75)
        {
          texCoordinate.x += 0.75;
          texCoordinate.z += 0.75;
        }

        yRandRotation.rotateY(random.w*TWO_PI);

        grass[nextGObject].vertices[ 0].vertex.set(-GRASS_WIDTH,       0.0f, 0.0f);
        grass[nextGObject].vertices[ 0].vertex *= yRandRotation;

        grass[nextGObject].vertices[ 1].vertex.set( GRASS_WIDTH,       0.0f, 0.0f);
        grass[nextGObject].vertices[ 1].vertex *= yRandRotation;

        grass[nextGObject].vertices[ 2].vertex.set( GRASS_WIDTH, randHeight, 0.0f);
        grass[nextGObject].vertices[ 2].vertex *= yRandRotation;

        grass[nextGObject].vertices[ 3].vertex.set(-GRASS_WIDTH, randHeight, 0.0f);
        grass[nextGObject].vertices[ 3].vertex *= yRandRotation;

        grass[nextGObject].vertices[ 0].uvJitter.set(texCoordinate.x, texCoordinate.y, jitter);
        grass[nextGObject].vertices[ 1].uvJitter.set(texCoordinate.z, texCoordinate.y, jitter);
        grass[nextGObject].vertices[ 2].uvJitter.set(texCoordinate.z, texCoordinate.w, jitter);
        grass[nextGObject].vertices[ 3].uvJitter.set(texCoordinate.x, texCoordinate.w, jitter);

        yRandRotation.rotateY(PI/3.0f);

        for(i0 = 4; i0 < 12; i0++)
        {
          grass[nextGObject].vertices[i0].uvJitter = grass[nextGObject].vertices[i0 - 4].uvJitter;
          grass[nextGObject].vertices[i0].vertex   = grass[nextGObject].vertices[i0 - 4].vertex;
          grass[nextGObject].vertices[i0].vertex  *= yRandRotation;
        }
 
        for(i0 = 0; i0 < 12; i0++)
        {
          grass[nextGObject].vertices[i0].binormal = vertices[index].binormal;
          grass[nextGObject].vertices[i0].tangent  = vertices[index].tangent;
          grass[nextGObject].vertices[i0].normal   = vertices[index].normal;
          grass[nextGObject].vertices[i0].offset   = vertexOffset;
        }

        indices[indicesCounter++] = indexOffset + 0;
        indices[indicesCounter++] = indexOffset + 1; 
        indices[indicesCounter++] = indexOffset + 3;
        indices[indicesCounter++] = indexOffset + 1;
        indices[indicesCounter++] = indexOffset + 2; 
        indices[indicesCounter++] = indexOffset + 3;

        indices[indicesCounter++] = indexOffset + 4; 
        indices[indicesCounter++] = indexOffset + 5; 
        indices[indicesCounter++] = indexOffset + 7;
        indices[indicesCounter++] = indexOffset + 5;
        indices[indicesCounter++] = indexOffset + 6;
        indices[indicesCounter++] = indexOffset + 7;

        indices[indicesCounter++] = indexOffset +  8;
        indices[indicesCounter++] = indexOffset +  9;
        indices[indicesCounter++] = indexOffset + 11;
        indices[indicesCounter++] = indexOffset +  9; 
        indices[indicesCounter++] = indexOffset + 10;
        indices[indicesCounter++] = indexOffset + 11;

        nextGObject++;
      }
    }
  } 
 
 	glUnmapBufferARB(GL_ARRAY_BUFFER_ARB);
  glBindBufferARB(GL_ARRAY_BUFFER_ARB, 0);

  glGenBuffersARB(1, &indexBufferID);
  glBindBufferARB(GL_ELEMENT_ARRAY_BUFFER_ARB, indexBufferID);
  glBufferDataARB(GL_ELEMENT_ARRAY_BUFFER_ARB, indexCount * sizeof(unsigned short),
                  indices, GL_STATIC_DRAW_ARB);

  status = (glGetError() == GL_NO_ERROR);
  glBindBufferARB(GL_ARRAY_BUFFER_ARB, 0);

  if(!status)
    return Logger::writeErrorLog("Could not generate a geometry buffer object, GRASS");

  deleteArray(indices);

  return true;
}

const Tuple2f        &GrassCell::getVerticalBounds()  { return verticalBounds;   }
const unsigned int    GrassCell::getGeometryBufferID(){ return geometryBufferID; }
const unsigned int    GrassCell::getTriangleCount()   { return indexCount/3;     }
const unsigned int    GrassCell::getIndexBufferID()   { return indexBufferID;    }
const unsigned short *GrassCell::getIndexStream()     { return indices;          }
