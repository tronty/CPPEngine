#include "TerrainCell.h"

unsigned short TerrainCell::indices[INDEX_COUNT];
unsigned int   TerrainCell::indexBufferID  =     0;
unsigned int   TerrainCell::userCount      =     0;

TerrainCell::TerrainCell()
{
  geometryBufferID  =         0;
  verticalBounds.x  =  10000.0f;
  verticalBounds.y  = -10000.0f;
  userCount        +=         1;
}

TerrainCell::~TerrainCell()
{
  if(geometryBufferID)
   glDeleteBuffersARB(1, &geometryBufferID);
}

bool  TerrainCell::setup(const HeightMap& heightmap,
                         const Tuple2i&   start)
{
  const HMVertex *vertices     =  heightmap.getVertexStream();
  TVertex        *gpuBuffer    =      NULL;
  float           maxHeight    = -20000.0f,
                  minHeight    =  20000.0f,
                  newHeight    =      0.0f;
  int             height       = heightmap.getHeight(),
                  width        = heightmap.getWidth(),
                  offset       = 0,
                  index        = 0,
                  x            = 0,
                  y            = 0;

  if(!vertices)
    return Logger::writeErrorLog("Null heightmap content");

  if(!(height == HEIGHT_MAP_DEPTH) || !(width == HEIGHT_MAP_WIDTH))
    return Logger::writeErrorLog("Heightmap has unexpected width or height");

  glGenBuffersARB(1, &geometryBufferID);
    
  glBindBufferARB(GL_ARRAY_BUFFER_ARB, geometryBufferID);
  glBufferDataARB(GL_ARRAY_BUFFER_ARB, TILE_COUNT * sizeof(TVertex),
                  NULL, GL_STATIC_DRAW_ARB);

  if(glGetError() == GL_NO_ERROR)
    gpuBuffer = (TVertex *)glMapBufferARB(GL_ARRAY_BUFFER_ARB, GL_WRITE_ONLY_ARB);
  else
   return Logger::writeErrorLog("Not enough memory for the interleaved geometry arrays");
 
  for(y = start.y; y < start.y + TILE_ROW_COUNT; y++)
  {
    y = clamp(y, 0, height - 1);
    for(x = start.x; x < start.x + TILE_COLUMN_COUNT; x++, offset++)
    {
      x          = clamp(x, 0, width - 1);
      index      = y*width + x;
      newHeight  = vertices[index].vertex.y;
      maxHeight  = newHeight > maxHeight ? newHeight : maxHeight;
      minHeight  = newHeight < minHeight ? newHeight : minHeight;

      gpuBuffer[offset].vertex = vertices[index].vertex;
      gpuBuffer[offset].normal = vertices[index].normal;
      gpuBuffer[offset].uv     = vertices[index].uv;
    }
  }

	glUnmapBufferARB(GL_ARRAY_BUFFER_ARB);
  glBindBufferARB(GL_ARRAY_BUFFER_ARB, 0);

  verticalBounds.set(minHeight, maxHeight);
 
  return true;
} 

const bool TerrainCell::render()
{
  static int offset1 = sizeof(Tuple2f),
             offset2 = sizeof(Tuple3f) + offset1;

  if(geometryBufferID)
  {
    glBindBufferARB(GL_ARRAY_BUFFER_ARB, geometryBufferID); 

    glEnableClientState(GL_TEXTURE_COORD_ARRAY);
    glTexCoordPointer(2, GL_FLOAT, sizeof(TVertex), OFFSET(0));
 
    glNormalPointer(GL_FLOAT, sizeof(TVertex), OFFSET(offset1));
    glEnableClientState(GL_NORMAL_ARRAY);
 
    glVertexPointer(3, GL_FLOAT, sizeof(TVertex), OFFSET(offset2));
    glEnableClientState(GL_VERTEX_ARRAY);
  }
 
  if(indexBufferID)
  {
    glBindBufferARB(GL_ELEMENT_ARRAY_BUFFER_ARB, indexBufferID);
    glDrawElements(GL_TRIANGLES, INDEX_COUNT, GL_UNSIGNED_SHORT,  0);
    glBindBufferARB(GL_ELEMENT_ARRAY_BUFFER_ARB, 0);
  }
  else
    glDrawElements(GL_TRIANGLES, INDEX_COUNT, GL_UNSIGNED_SHORT, indices);

  if(geometryBufferID)
  {
    glBindBufferARB(GL_ARRAY_BUFFER_ARB, 0); 
    glDisableClientState(GL_TEXTURE_COORD_ARRAY);
    glDisableClientState(GL_NORMAL_ARRAY);
    glDisableClientState(GL_VERTEX_ARRAY);
  }

  return (geometryBufferID != 0);
}

const unsigned int TerrainCell::getIndexBufferID()
{
  return indexBufferID;
}

const Tuple2f &TerrainCell::getVerticalBounds()  { return verticalBounds;   }

/*
const bool TerrainCell::renderAABB()
{
  if(visiblePixelsCount)
    aabb.render(BoundsDescriptor::WIRE | BoundsDescriptor::AABB);

  return (visiblePixelsCount != 0);
}*/

const unsigned int TerrainCell::getGeometryBufferID() const
{
  return geometryBufferID;
}

const unsigned short *TerrainCell::getIndexStream()
{
  return indices;
}

void TerrainCell::setupIndices(bool compile)
{
  bool initialized = false;

  if(initialized)
    return;

  register int index = 0;
  
  for(int y = 0; y < TILE_ROW_COUNT - 1; y++)
  {
    for(int x = 0; x < TILE_COLUMN_COUNT - 1; x++)
    {
      indices[index++] = (y + 0)*TILE_COLUMN_COUNT + x;
      indices[index++] = (y + 1)*TILE_COLUMN_COUNT + x;
      indices[index++] = (y + 0)*TILE_COLUMN_COUNT + x + 1;

      indices[index++] = (y + 1)*TILE_COLUMN_COUNT + x;
      indices[index++] = (y + 1)*TILE_COLUMN_COUNT + x + 1;
      indices[index++] = (y + 0)*TILE_COLUMN_COUNT + x + 1;
    }
  }

  if(compile && GL_ARB_vertex_buffer_object)
  {
    glGenBuffersARB(1, &indexBufferID);
    glBindBufferARB(GL_ELEMENT_ARRAY_BUFFER_ARB, indexBufferID);
    glBufferDataARB(GL_ELEMENT_ARRAY_BUFFER_ARB, INDEX_COUNT * sizeof(unsigned short),
                    indices, GL_STATIC_DRAW_ARB);

    if(glGetError() != GL_NO_ERROR) 
      Logger::writeErrorLog("Could not generate the index buffer object");

    glBindBufferARB(GL_ELEMENT_ARRAY_BUFFER_ARB, 0);
  }
  initialized = true;
}