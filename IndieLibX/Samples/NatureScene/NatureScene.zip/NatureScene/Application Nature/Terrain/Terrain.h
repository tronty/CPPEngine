#ifndef TERRAIN_H
#define TERRAIN_H

#include "../../Appearance/Appearance.h"
#include "../../Tools/FPSCounter.h"
#include "../../Viewer/Frustum.h"
#include "../../Viewer/Camera.h"
#include "HeightMap.h"
#include "Portal.h"


typedef DistanceObject<Portal*> LPPortal;
typedef vector<LPPortal>        LPPortalManager;
class Terrain
{
  public:
    Terrain();
   ~Terrain();

    Tuple4i &renderSimple(float elapsedTime);
    Tuple4i &render(const Camera   &camera,
                    const Frustum &frustum,
                    float elapsedTime );

    bool  initialize(bool compile = false);

    const void adjustCameraYLocation(Camera &camera, float cameraRadius);

    void  setOcclusionCullingFlag(bool occCull);
    void  setAlphaToCoverageFlag(bool alpha);
    void  setFrustumCullingFlag(bool frCull);
    void  setRenderAABBFlag(bool  rAABBs);
    void  setWireFrameFlag(bool  wFrame);
    void  setDrawGrassFlag(bool  dGrass);
    void  setDrawTBNFlag(bool  dGrass);

    void  setAlphaReference(float refrence);
    void  setAlphaBooster(float boost);

    const float getAlphaReference();
    const float getAlphaBooster();

    const bool  getOcclusionCullingFlag();
    const bool  getAlphaToCoverageFlag();
    const bool  getFrustumCullingFlag();
    const bool  getRenderAABBFlag();
    const bool  getWireFrameFlag();
    const bool  getDrawGrassFlag();
    const bool  getDrawTBNFlag();

    const Texture &getDiffuse();
    const Texture &getDetail();
    const Shaders &getShader();
 
    
  private:
    void  createRandomMap(int w, int h, Image &image);
    void  resetRenderingRoutine();
    bool  appendToGreenChannel(Image &dst, const  Image &src);

    Matrix4f  prevView;
    Tuple4i   info;

    Texture   grassPack,
              fungus,
              weight,
              grass,
              dirt;

    Shaders   terrainShader,
              grassShader;

    LPPortalManager  portalsManager;
    Portal          *portals;

    HeightMap    terrainInfo;
  
    float        alphaReference,
                 alphaBooster;

    bool         occlusionCullCells,
                 frustumCullCells,
                 renderCellsAABBs,
                 alphaToCoverage,
                 queryClock,
                 drawGrass,
                 wireFrame,
                 drawTBN,
                 dirty;
};
#endif