#ifndef GRASS_CELL_H
#define GRASS_CELL_H

#include "TerrainUtils.h"
#include "TerrainCell.h"

typedef struct grassVertex
{
  Tuple3f uvJitter;
  Tuple3f binormal,
          tangent,
          offset,
          normal,
          vertex;
} GVertex;

typedef struct gBlock
{
  GVertex vertices[12];
} GrassBlock;

class GrassCell
{
  public:
    GrassCell();
   ~GrassCell();

    bool  setup(const HeightMap &distribution,
                const Tuple2i   &offset,
                const Image     &randommap,
				const Image     &coveragemap);

    const bool            render();
    const Tuple2f        &getVerticalBounds();
    const unsigned int    getGeometryBufferID();
    const unsigned int    getIndexBufferID();
    const unsigned int    getTriangleCount();
    const unsigned short *getIndexStream();
  private:
    unsigned int    geometryBufferID,
                    indexBufferID,
                    blockCount,
                    indexCount;
    unsigned short *indices;
    Tuple2f         verticalBounds;
};

#endif
