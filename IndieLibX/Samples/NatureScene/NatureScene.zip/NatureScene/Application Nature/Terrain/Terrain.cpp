#include "Terrain.h"

Terrain::Terrain()
{
  occlusionCullCells  =   true;
  frustumCullCells    =   true;
  renderCellsAABBs    =  false;
  alphaToCoverage     =   true;
  alphaReference      =  0.25f;
  alphaBooster        =   1.5f;
  queryClock          =  false;
  wireFrame           =  false;
  drawGrass           =   true;
  drawTBN             =  false;
  portals             =   NULL;
  dirty               =  false;
}

bool  Terrain::initialize(bool compile)
{
  if(portals)
    return true;

  if(!GLEE_ARB_vertex_buffer_object)
    return Logger::writeErrorLog("This demo needs the GL_ARB_vertex_buffer_object extension to run");

  register int index = 0,
               x     = 0,
               y     = 0;

  Image        randommap,
               heightmap,
			         coverage,
               watermap;

  if(!watermap.load("watermap.jpg"))
    return Logger::writeErrorLog("Invalid watermap image");

  if(!coverage.load("coverage.png"))
    return Logger::writeErrorLog("Invalid coverage image");

  if(!heightmap.load("heightmap.jpg"))
    return Logger::writeErrorLog("Invalid heightmap image");
  
  if(!terrainInfo.setup(heightmap, watermap))
    return false;

  createRandomMap(heightmap.getWidth(), heightmap.getHeight(), randommap);

  portals     = new Portal[CELL_COUNT];
  int     xOf    = 0, yOf = 0,
          xRatio = HEIGHT_MAP_WIDTH/CELL_COLUMN_COUNT,
          yRatio = HEIGHT_MAP_DEPTH/CELL_ROW_COUNT;

  for(y = 0; y < CELL_ROW_COUNT; y++)
  for(x = (CELL_COLUMN_COUNT - 1); x > -1; x--)
  {
    index = y*CELL_COLUMN_COUNT + x;
    portalsManager.push_back(portals + index);

    xOf = (x == (CELL_COLUMN_COUNT - 1)) ? -1 : 0;
    yOf = (y == (CELL_ROW_COUNT    - 1)) ? -1 : 0;

    if(!portals[index].setup(terrainInfo,  Tuple2i(x*xRatio + xOf, y*yRatio + yOf), randommap, coverage))
      return Logger::writeErrorLog(String("Error setting up portal ") + index);
  }

  TerrainCell::setupIndices(compile);
  appendToGreenChannel(watermap, heightmap);

  dirt.load2D("dirt.dds", GL_REPEAT, GL_REPEAT, GL_LINEAR, GL_LINEAR_MIPMAP_LINEAR, true); 
  dirt.setAnisoLevel(2);

  fungus.load2D("fungus.dds", GL_REPEAT, GL_REPEAT, GL_LINEAR, GL_LINEAR_MIPMAP_LINEAR, true); 
  fungus.setAnisoLevel(2);

  grass.load2D("grasslayer.dds", GL_REPEAT, GL_REPEAT, GL_LINEAR, GL_LINEAR_MIPMAP_LINEAR, true); 
  grass.setAnisoLevel(2);

  weight.load2DImage(watermap, GL_CLAMP, GL_CLAMP, GL_LINEAR, GL_LINEAR_MIPMAP_LINEAR, true); 
  weight.setAnisoLevel(2);

  grassPack.load2D("grassPack.dds", GL_REPEAT, GL_CLAMP_TO_EDGE, GL_LINEAR, GL_LINEAR_MIPMAP_LINEAR, true);
  grassPack.setAnisoLevel(4);

  terrainShader.loadXMLSettings("TerrainShader.xml");
  grassShader.loadXMLSettings("GrassShader.xml");

  return true;
}

Tuple4i &Terrain::render(const Camera     &camera,
                         const Frustum    &frustum,
                         float elapsedTime )
{
  if(portals)
  {
    GrassCell    *gCell        = NULL;
    Portal       *portal       = NULL;         
    int           visibleCells = 0,
                  index        = 0,
                  x            = 0,
                  y            = 0;

    if(prevView != camera.getModelViewMatrix())
    {
      const Tuple3f  &viewerPosition = camera.getViewerPosition();
                      prevView       = camera.getModelViewMatrix();

      for(y = 0; y < CELL_ROW_COUNT; y++)
      for(x = 0; x < CELL_COLUMN_COUNT; x++)
      {
        index = y*CELL_COLUMN_COUNT + x;
        portals[index].setVisiblePixelsCount(frustumCullCells ? frustum.AABBInFrustum(portals[index].getAABB()) : true);
        portalsManager[index].set(viewerPosition.getDistance(portals[index].getAABB().getCenterAABB()),
                                  portals + index);
      }
   
      sort(portalsManager.begin(), portalsManager.end());

      if(occlusionCullCells && GLEE_ARB_occlusion_query)
        queryClock = true;
    }
    else
    {
      if(queryClock)
      {
        for(x = 3; x < CELL_COUNT; x++)
          portalsManager[x].getObject()->endOcclusionQuery();
      }
      queryClock = false;
    }
  }
  dirty = true;

  return renderSimple(elapsedTime);
}

Tuple4i &Terrain::renderSimple(float elapsedTime)
{
  info.set(0,0,0,0);
  if(portals)
  {
    GrassCell    *gCell        = NULL;
    Portal       *portal       = NULL;         
    int           visibleCells = 0,
                  index        = 0,
                  x            = 0,
                  y            = 0;

    glPolygonMode(GL_FRONT_AND_BACK, wireFrame ? GL_LINE : GL_FILL);
 
    terrainShader.activate();
    weight.activate(0);
    fungus.activate(1);
    dirt.activate(2);
    grass.activate(3);

    if(queryClock && dirty)
    {
      for(x = 0; x < CELL_COUNT; x++)
      {
        portalsManager[x].getObject()->startOcclusionQuery();
        visibleCells += (portalsManager[x].getObject()->getVisiblePixelsCount() != 0);
      }
    }
    else
      for(x = 0; x < CELL_COUNT; x++)
        visibleCells += portalsManager[x].getObject()->render(Portal::TERRAIN) ? 1 : 0;
 
    grass.deactivate();
    dirt.deactivate();
    fungus.deactivate();
    weight.deactivate();

    terrainShader.deactivate();

    if(drawGrass)
    {
      if(alphaToCoverage)
      {
        glEnable(GL_MULTISAMPLE_ARB);
        glEnable(GL_SAMPLE_ALPHA_TO_COVERAGE_ARB);
      }

      glEnable(GL_ALPHA_TEST);
      glDisable(GL_CULL_FACE);

      glAlphaFunc(GL_GEQUAL, alphaReference);

      grassShader.updateElementsf("alphaBooster", 1, &alphaBooster);
      grassShader.updateElementsf("elapsedTime",  1, &elapsedTime);
      grassShader.activate();

      grassPack.activate();

      for(x = 0; x < CELL_COUNT; x++)
      {
        gCell = &portalsManager[x].getObject()->getGrassCell();
        if(portalsManager[x].getObject()->render(Portal::GRASS))
          info.x += gCell->getTriangleCount();
      }

      if(alphaToCoverage)
      {
        glDisable(GL_MULTISAMPLE_ARB);
        glDisable(GL_SAMPLE_ALPHA_TO_COVERAGE_ARB);
      }

      grassPack.deactivate();
      grassShader.deactivate();

      glEnable(GL_CULL_FACE);
      glDisable(GL_ALPHA_TEST);
    }

    glPolygonMode(GL_FRONT_AND_BACK, GL_FILL);

    if(renderCellsAABBs)
      for(y = 0; y < CELL_ROW_COUNT; y++)
      for(x = 0; x < CELL_COLUMN_COUNT; x++)
        portals[y*CELL_COLUMN_COUNT + x].render(Portal::AABB);
 
    if(drawTBN)
      terrainInfo.render();

    info.x += (TILE_COLUMN_COUNT - 1)*TILE_ROW_COUNT*visibleCells;
    info.y  = visibleCells*100/CELL_COUNT;
  }

   dirty = false;

  return info;
}

bool  Terrain::appendToGreenChannel(Image &dst, const  Image &src)
{
  GLubyte *hmBytes  = (GLubyte*)dst.getDataBuffer(),
          *wmBytes  = (GLubyte*)src.getDataBuffer();

  int      hmByteCount  = dst.getComponentsCount(),
           wmByteCount  = src.getComponentsCount(),
           height       = dst.getHeight(),
           width        = dst.getWidth(),
           index        = 0;

  if(!wmBytes || ! hmBytes)
    return Logger::writeErrorLog("Null heightmap or watermap content");

  if(!(height == src.getHeight()) || !(width == src.getWidth()))
    return Logger::writeErrorLog("Watermap has unexpected width or height");

  for(int y = 0; y < height; y++)
  {
    for(int x = 0; x < width; x++)
    {
      index                          = (y*width + x);
      hmBytes[index*hmByteCount + 1] = wmBytes[index*wmByteCount];
    }
  }
  return true;
}

const void Terrain::adjustCameraYLocation(Camera &camera, float cameraRadius)
{
  Tuple3f position   = camera.getViewerPosition();
  float   height     = terrainInfo.getInterpolatedHeight(position),
          difference = (height - position.y + cameraRadius);
  if(difference > 0.1f)
    camera.elevate(difference);
}

void  Terrain::resetRenderingRoutine()
{
  prevView.setIdentity();  
  queryClock = false;   
}

void  Terrain::setOcclusionCullingFlag(bool occCull){ occlusionCullCells = occCull;
                                                      resetRenderingRoutine();     }
void  Terrain::setAlphaToCoverageFlag(bool alpha)   { alphaToCoverage    = alpha;  }
void  Terrain::setFrustumCullingFlag(bool frCull)   { frustumCullCells   = frCull;
                                                      resetRenderingRoutine();     }
void  Terrain::setRenderAABBFlag(bool  rAABBs)      { renderCellsAABBs   = rAABBs; }
void  Terrain::setWireFrameFlag(bool  wFrame)       { wireFrame          = wFrame; }
void  Terrain::setDrawGrassFlag(bool  dGrass)       { drawGrass          = dGrass; }
void Terrain::setDrawTBNFlag(bool  dTBN)            { drawTBN            = dTBN;   }

void  Terrain::setAlphaReference(float ref)         { alphaReference     = ref;    }
void  Terrain::setAlphaBooster(float boost)         { alphaBooster       = boost;  }

const bool  Terrain::getAlphaToCoverageFlag(){ return alphaToCoverage ;    }
const bool  Terrain::getFrustumCullingFlag() { return frustumCullCells;    }
const bool  Terrain::getRenderAABBFlag()     { return renderCellsAABBs;    }
const bool  Terrain::getWireFrameFlag()      { return wireFrame;           }
const bool  Terrain::getDrawGrassFlag()      { return drawGrass;           }
const bool  Terrain::getDrawTBNFlag()        { return drawTBN;             }

const float Terrain::getAlphaReference()     { return alphaReference;      }
const float Terrain::getAlphaBooster()       { return alphaBooster;        }

void Terrain::createRandomMap(int width, int height, Image &image)
{
  const char* verified = MediaPathManager::lookUpMediaPath("randommap.tga");

  if(verified)
  {
    image.load(verified);
    return;
  }


	ofstream randommap;

  randommap.open("randommap.tga", ios::binary);

	GLubyte	 TGAheader[12] = {0, 0, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0},
           infoHeader[6];

  
  Tuple4<unsigned char> *data = new Tuple4<unsigned char>[width*height];

  for(int y = 0, index = 0; y < height; y++)
  for(int x = 0; x < width ; x++, index++)
  {
    data[index].set(unsigned char(getNextRandom()*255.0f),
                    unsigned char(getNextRandom()*255.0f),
                    unsigned char(getNextRandom()*255.0f),
                    unsigned char(getNextRandom()*255.0f));
  }

	randommap.write((char*)TGAheader, sizeof(TGAheader));

	infoHeader[0] = (width  & 0x00FF);
	infoHeader[1] = (width  & 0xFF00) >> 8;
	infoHeader[2] = (height & 0x00FF);
	infoHeader[3] = (height & 0xFF00) >> 8;
	infoHeader[4] = 32;
	infoHeader[5] = 0;

	randommap.write((char*)infoHeader, sizeof(infoHeader));
	randommap.write((char*)data, 4*width*height);
	randommap.close();

  image.setComponentsCount(4);
  image.setInternalFormat(GL_RGBA8);
  image.setFormat(GL_RGBA);
  image.setHeight(height);
  image.setWidth(width);
  image.setDataBuffer(&data[0].x);
 
  deleteArray(data);
}

Terrain::~Terrain()
{
  deleteArray(portals);
  portalsManager.clear();

  terrainShader.destroy();
  grassShader.destroy();

}