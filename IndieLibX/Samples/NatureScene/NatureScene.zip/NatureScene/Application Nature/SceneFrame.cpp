#include "../Tools/Factory3DS.h"
#include "SceneFrame.h"

SceneFrame::SceneFrame(HINSTANCE instance) : IOXMLObject("SceneFrame")
{
  Logger::initialize();
  MediaPathManager::registerPath("Data/XML/");

  window.setInputEventListener(this);
  window.setAppInstance(instance);
  skyInfo.set(0.25f, 0.5f, 1.0f, 1.0f);

  benchmark.setEnabled(false);
  mouseLocked  = false;
  renderWater  =  true;
  active       =  true;
  paused       = false;
}

bool SceneFrame::initialize()
{
  GUIPanel *loading  = NULL;
  srand((unsigned) time( NULL));

  if(!IOXMLObject::loadXMLSettings("Data/IniFile.xml"))
    return false;

  Logger::writeInfoLog(String("Renderer: ") + (char*)glGetString(GL_RENDERER));
  Logger::writeInfoLog(String("Version:  ") + (char*)glGetString(GL_VERSION));
  Logger::writeInfoLog(String("Vendor:   ") + (char*)glGetString(GL_VENDOR));

  camera.setup(510.0f, 68.0f, 2210.0f,
               652.0f, 95.0f, 1670.0f,
                 0.0f,  1.0f,    0.0f);

  glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
  glEnable(GL_DEPTH_TEST);
  glEnable(GL_CULL_FACE);
  glCullFace(GL_BACK);
  glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);

  setPerspective(WindowEvent(0, 0, window.getWidth(), window.getHeight()));
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT | GL_STENCIL_BUFFER_BIT);

  if(loading = (GUIPanel*)guiFrame.getWidgetByCallbackString("LoadingPanel"))
  {
    Renderer::enter2DMode(window.getWidth(), window.getHeight());
    loading->render(0.0f);
    Renderer::exit2DMode();
  }

  window.setVisible(true);
  window.update();

  waterTexture.create2DShell("Water Texture", 512, 512, GL_RGBA8, GL_RGBA, GL_CLAMP_TO_EDGE, GL_CLAMP_TO_EDGE);

  waterShader.loadXMLSettings("WaterShader.xml");
  waterGroup.IOXMLObject::loadXMLSettings("WaterGroup.xml");
  waterGroup.compile();

  skyShader.loadXMLSettings("Skyshader.xml");
  skyDome.IOXMLObject::loadXMLSettings("SkyGroup.xml");
  skyDome.compile();
 
  guiFrame.setGUIEventListener(this);
  if(loading)
    loading->setVisible(false);

  guiFrame.setVisible(true);
  camera.update(0.001f);
  
  terrain.initialize(true);
  Logger::flush();

  TextureInfo *wDepth = TexturesManager::getTextureInfo("Data/Terrain/watermap.jpg");
  waterDepth.setID(wDepth ? wDepth->getMedia() : 0);
  return  (waterDepth.getID() != 0);
}

void SceneFrame::updateClipPlanes(float nearClip, float farClip)
{
  glMatrixMode(GL_PROJECTION);
  glLoadIdentity();
  gluPerspective(90.0f, (float)window.getWidth()/window.getHeight(), nearClip, farClip);
  glMatrixMode(GL_MODELVIEW);
}

bool SceneFrame::run()
{
  static  float privateTimeClock = 0.0f;
  Tuple4i sceneInfo;
  float   frameInterval          = benchmark.getFrameInterval();
  int     renderedTriangles      = 0,
          waterMeshTri           = 0;

  benchmark.markFrameStart();

  updateWaterSurface(privateTimeClock);

  setPerspective(WindowEvent(0,0, window.getWidth(), window.getHeight()));
  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

  terrain.adjustCameraYLocation(camera, 60.0f);
  camera.update(benchmark.getFrameInterval());
  frustum.update();

  sceneInfo    = terrain.render(camera, frustum, privateTimeClock);
  waterMeshTri = renderWaterSurface(privateTimeClock);
  sceneInfo.x += renderSkyDome();
  sceneInfo.x += waterMeshTri;

  if(triCounter) triCounter ->setLabelString(String("Triangle count: ") + sceneInfo.x*(waterMeshTri ? 2 : 1));
  if(cellCounter)cellCounter->setLabelString(String("Visible Cells: ")  + sceneInfo.y + "%");
  if(fpsCounter) fpsCounter ->setLabelString(String("Current FPS: ")    + int(benchmark.getFPS()));

  Renderer::enter2DMode(window.getWidth() , window.getHeight());
    guiFrame.render(frameInterval);
  Renderer::exit2DMode();

  window.update(frameInterval);
  benchmark.markFrameEnd();

  privateTimeClock += frameInterval*!paused;

  return benchmark.running();
}

int SceneFrame::renderSkyDome()
{
  TransformGroup *parent      = skyDome.getGroup("directParent");
  static float    skyTimer    = 0.0f;
  const  float    timeScale   = 0.0125f;
  int             skyTriCount = 0;

  parent = parent ? parent : &skyDome;

  const BoundsDescriptor &aabb = parent->getBoundsDescriptor();
  
  updateClipPlanes(25.0f, 9000.0f);

  skyShader.updateElementsf("skyInfo", 4, skyInfo);
  skyShader.updateElementsf("params",  4, Tuple4f(aabb.getExtents(), skyTimer));
  skyShader.updateElementsf("offset",  3, Tuple3f(aabb.getMinEndAABB())*-1.0);
 
  skyDome.getTransform().setTranslations(camera.getViewerPosition());

  skyShader.activate();
  skyTriCount = skyDome.render(ALL_EFFECTS);
  skyShader.deactivate();

  skyTimer += !paused*timeScale*skyInfo.w*benchmark.getFrameInterval();
  return skyTriCount;
}

int  SceneFrame::renderWaterSurface(float timer)
{ 
  if(!renderWater || !frustum.AABBInFrustum(waterGroup.getBoundsDescriptor()))
    return 0;

  int  waterTriCount = 0;
  
  glEnable(GL_BLEND);
  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
  waterTexture.getTransform().set(waterMatrix);

  waterTexture.activate(1);
  waterDepth.activate(2);

  waterShader.activate();
  waterTriCount += waterGroup.render(ALL_EFFECTS, &frustum);

  waterShader.deactivate();
  waterDepth.deactivate();
  waterTexture.deactivate();

  glDisable(GL_BLEND);

  return waterTriCount;
}

void SceneFrame::updateWaterSurface(float timer)
{
  if(!renderWater || !frustum.AABBInFrustum(waterGroup.getBoundsDescriptor()))
    return;

  const Matrix4f &transform       = waterGroup.getTransform().getMatrix4f();
  Matrix4f        inverseTranView = camera.getModelViewMatrix(),
                  projection;
                  
  Tuple4f         cameraPosition,
                  translation;

  cameraPosition.set(camera.getViewerPosition(), 0.0f);
  inverseTranView.setInverseTranspose();

  waterMatrix.set(0.5f, 0.0f, 0.0f, 0.0f,
                  0.0f, 0.5f, 0.0f, 0.0f, 
                  0.0f, 0.0f, 0.5f, 0.0f,
                  0.5f, 0.5f, 0.5f, 1.0f);

  setPerspective(WindowEvent(0, 0, waterTexture.getWidth(), waterTexture.getHeight()));
  projection.setPerspective(90.0f, float(window.getWidth())/window.getHeight(), 4.0f, 7500.0f);

  modifyProjectionMatrix(Tuple4f(0.0f, -1.0f, 0.0f, 0.0f)*inverseTranView);
  camera.update(benchmark.getFrameInterval());
  frustum.update();

  projection  *= camera.getModelViewMatrix();
  waterMatrix *= projection;

  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

  glFrontFace(GL_CW);

  glPushMatrix();
    glTranslatef(0.0, transform.m[13], 0.0);
    glScalef(1.0f, -1.0f, 1.0f);
    terrain.renderSimple(timer);
    renderSkyDome();
  glPopMatrix();
 
  glFrontFace(GL_CCW);

  waterTexture.copyCurrentBuffer();

  translation.set(transform[12], transform[13],  transform[14], 0.0f);
  waterShader.updateElementsf("terrainInfo", 4,  Tuple4f(-TERRAIN_X_OFFSET*TERRAIN_WIDTH_SCALE,
                                                         -TERRAIN_Z_OFFSET*TERRAIN_DEPTH_SCALE,
                                                          TERRAIN_WIDTH_SCALE*255.0f,
                                                          TERRAIN_DEPTH_SCALE*255.0f));
  waterShader.updateElementsf("translation", 4,  translation);
  waterShader.updateElementsf("camera",      4,  cameraPosition);
  waterShader.updateElementsf("timer",       1, &timer);
} 

void SceneFrame::actionPerformed(GUIEvent &evt)
{
  const String &callbackString  = evt.getCallbackString();
  GUIRectangle *sourceRectangle = evt.getEventSource();
  int           widgetType      = sourceRectangle->getWidgetType();

  if(widgetType == CHECK_BOX)
  {
    GUICheckBox   *checkBox = (GUICheckBox*)sourceRectangle;
    if(checkBox->isClicked())
    {
      if(callbackString == "aToCoverage") terrain.setAlphaToCoverageFlag(checkBox->isChecked());
      if(callbackString == "eOcclusion")  terrain.setOcclusionCullingFlag(checkBox->isChecked());
      if(callbackString == "eFrustum")    terrain.setFrustumCullingFlag(checkBox->isChecked());
      if(callbackString == "rGrass")      terrain.setDrawGrassFlag(checkBox->isChecked());
      if(callbackString == "rWater")      renderWater = checkBox->isChecked();
      if(callbackString == "rAABB")       terrain.setRenderAABBFlag(checkBox->isChecked());
      if(callbackString == "rMode")       terrain.setWireFrameFlag(checkBox->isChecked());
      if(callbackString == "rTBN")        terrain.setDrawTBNFlag(checkBox->isChecked());
    }
  }

  if(widgetType == SLIDER)
  {
    GUISlider   *slider = (GUISlider*)sourceRectangle;

    if(callbackString == "aReference")
    {
      terrain.setAlphaReference(slider->getProgress());
      slider->setLabelString(String("Alpha Reference: ") + slider->getProgress());
    }

    if(callbackString == "aBooster")
    {
      terrain.setAlphaBooster((slider->getProgress()*2.0f));
      slider->setLabelString(String("Alpha Booster: ") + terrain.getAlphaBooster()); 
    }

    if(callbackString == "red")
    {
      skyInfo.x = slider->getProgress();
      slider->setLabelString(String("Red Intensity: ") + skyInfo.x); 
    }

    if(callbackString == "blue")
    {
      skyInfo.z = slider->getProgress();
      slider->setLabelString(String("Blue Intensity: ") + skyInfo.z); 
    }

    if(callbackString == "green")
    {
      skyInfo.y = slider->getProgress();
      slider->setLabelString(String("Green Intensity: ") + skyInfo.y); 
    }

    if(callbackString == "sSpeed")
    {
      skyInfo.w = slider->getProgress()*2.0f;
      slider->setLabelString(String("Scrolling Speed: ") + slider->getProgress()); 
    }
  }
}

void SceneFrame::setPerspective(WindowEvent &evt)
{
  glViewport(0, 0, evt.getWidth(), evt.getHeight());
  glMatrixMode(GL_PROJECTION);

  updateClipPlanes(10.0f, 4000.0f);
  glLoadIdentity();

  if((evt.getWidth() == window.getWidth()) && (evt.getHeight() == window.getHeight()))
  {
    guiFrame.setPosition(0,0);
    guiFrame.setDimensions(float(window.getWidth()), float(window.getHeight()));
    guiFrame.forceUpdate(true);
  }
}

void SceneFrame::keyReleased(KeyEvent evt)
{
  camera.setKeyboardInput(evt, false);
  switch(evt.getKeyID())
  {
    case KEY_F8:
      window.scheduleSnapshot();
    break;
    case KEY_PAUSE:
      paused = !paused;
    break;
  }
}

void SceneFrame::keyPressed (KeyEvent evt)
{
  GUIRectangle *rectangle = NULL;

  camera.setKeyboardInput(evt, true);
  switch(evt.getKeyID())
  {
    case KEY_H:
     if(rectangle = guiFrame.getWidgetByCallbackString("User Controls"))
       rectangle->setVisible(!rectangle->isVisible());
    break;

    case KEY_ESCAPE: active = false; break;
  }
}

bool SceneFrame::loadXMLSettings(XMLElement *element)
{
  if(!isSuitable(element))
    return false;

  XMLElement  *child   = NULL;
  bool         success = false;

  for(size_t i = 0; i < element->getChildrenCount(); i++)
  {
    child = element->getChild(i);

    if(child->getName() == "MediaFolder")
    {
      MediaPathManager::registerPath(child);
      continue;
    }
  }

  if(child = element->getChildByName("Window"))
    success = window.loadXMLSettings(child);

  if(child = element->getChildByName("guiPath"))
  if(guiFrame.GUIPanel::loadXMLSettings(child->getValuec()))
  {
    GUISlider *slider = NULL;
    if(slider = (GUISlider*)guiFrame.getWidgetByCallbackString("red"))    skyInfo.x = slider->getProgress();
    if(slider = (GUISlider*)guiFrame.getWidgetByCallbackString("blue"))   skyInfo.z = slider->getProgress();
    if(slider = (GUISlider*)guiFrame.getWidgetByCallbackString("green"))  skyInfo.y = slider->getProgress();
    if(slider = (GUISlider*)guiFrame.getWidgetByCallbackString("sSpeed")) skyInfo.w = slider->getProgress()*2.0f;

    userControls = (GUIPanel*)guiFrame.getWidgetByCallbackString("User Controls");
    statistics   = (GUIPanel*)guiFrame.getWidgetByCallbackString("Statistics");
    cellCounter  = (GUILabel*)guiFrame.getWidgetByCallbackString("cellCounter");
    triCounter   = (GUILabel*)guiFrame.getWidgetByCallbackString("triCounter");
    fpsCounter   = (GUILabel*)guiFrame.getWidgetByCallbackString("fpsCounter");
  }
  else
    success = false;

  if(child = element->getChildByName("Benchmark"))
    benchmark.loadXMLSettings(child);

  return success;
}

void SceneFrame::mouseDoubleClicked(MouseEvent evt)
{ 
  if(userControls)
  {
    const Tuple4i &windowBounds = userControls->getWindowBounds();
    mouseLocked  = (evt.getY() >= windowBounds.y) &&
                   (evt.getY() <= windowBounds.w) &&
                   (evt.getX() >= windowBounds.x) &&
                   (evt.getX() <= windowBounds.z);
  }

  guiFrame.checkMouseEvents(evt, CLICKED );
}

void SceneFrame::mouseReleased(MouseEvent evt)
{ 
  guiFrame.checkMouseEvents(evt, RELEASED); 
  mouseLocked = false;
}

void SceneFrame::mouseClicked(MouseEvent evt)
{ 
  if(userControls)
  {
    const Tuple4i &windowBounds = userControls->getWindowBounds();
    mouseLocked  = (evt.getY() >= windowBounds.y) &&
                   (evt.getY() <= windowBounds.w) &&
                   (evt.getX() >= windowBounds.x) &&
                   (evt.getX() <= windowBounds.z);
  }
  guiFrame.checkMouseEvents(evt, CLICKED ); 
}

void SceneFrame::mouseDragged(MouseEvent evt)
{
  camera.lockMouse(!mouseLocked);
  camera.setMouseInfo(evt.getX(), evt.getY());
  guiFrame.checkMouseEvents(evt, DRAGGED ); 
}

void SceneFrame::mouseMoved(MouseEvent evt)
{ 
  camera.lockMouse(false);

  camera.setMouseInfo(evt.getX(), evt.getY());
  guiFrame.checkMouseEvents(evt, MOVED   ); 
}

void SceneFrame::destroy()
{
  TexturesManager::flushAllTextures();
  guiFrame.clear();
  active = false;
}

SceneFrame::~SceneFrame()
{
  destroy();
  Logger::flush();
}