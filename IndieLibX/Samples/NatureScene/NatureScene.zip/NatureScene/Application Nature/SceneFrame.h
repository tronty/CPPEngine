#ifndef SCENEFRAME_H
#define SCENEFRAME_H

#include "../Renderer/FrameBufferObject.h"
#include "../Events/InputEventListener.h"
#include "../Events/GUIEventListener.h"
#include "../Nodes/TransformGroup.h"
#include "../Renderer/Renderer.h"
#include "../Tools/Benchmark.h"
#include "../Window/Window.h"

#include "../GUI/GUIUtils.h"
#include "Terrain/Terrain.h"


class SceneFrame : public InputEventListener, public IOXMLObject, public GUIEventListener
{


  public:
    SceneFrame(HINSTANCE instance = NULL);
   ~SceneFrame();

    bool initialize();
    void destroy();
    bool run();

    void setActive(bool act){ active = act;  }
    bool isActive()         { return active; }

    virtual bool loadXMLSettings(XMLElement *element);
    virtual bool exportXMLSettings(ofstream &xmlFile){return true; }

    virtual void windowPositionChanged(WindowEvent evt){setPerspective(evt);};
    virtual void windowSizeChanged    (WindowEvent evt){setPerspective(evt);};
    virtual void windowMaximized      (WindowEvent evt){setPerspective(evt);};
    virtual void windowMinimized      (WindowEvent evt){setPerspective(evt);};
    virtual void windowClosing        (WindowEvent evt){};

    virtual void mouseDoubleClicked(MouseEvent evt);
    virtual void mouseScrolled     (MouseEvent evt){};
    virtual void mouseReleased     (MouseEvent evt);
    virtual void mouseClicked      (MouseEvent evt);
    virtual void mouseDragged      (MouseEvent evt);
    virtual void mouseMoved        (MouseEvent evt);
    virtual void mouseExit         (MouseEvent evt){};

    virtual void keyReleased(KeyEvent evt);
    virtual void keyPressed (KeyEvent evt);

    virtual void actionPerformed(GUIEvent &evt);

  private:
    int    renderWaterSurface(float timer);
    void   setPerspective(WindowEvent &evt);
    void   updateWaterSurface(float timer);
    void   updateClipPlanes(float nearClip, float farClip);
    int    renderSkyDome();

    Benchmark        benchmark;
    GUIFrame         guiFrame;

    GUIPanel        *userControls,
                    *statistics;

    GUILabel        *cellCounter, 
                    *triCounter,
                    *fpsCounter;

    Texture           waterTexture,
                      waterDepth;

    Shaders           waterShader,
                      skyShader;

    Tuple4f          skyInfo;

    Tuple2i          mouseLockedPosition;

    TransformGroup   waterGroup,
                     skyDome;
                    
    Terrain          terrain;
    Frustum          frustum;
    Camera           camera;

    Matrix4f         waterMatrix;
    Window           window;

    bool             mouseLocked,
		                 renderWater,
                     paused,
                     active;
};

#endif