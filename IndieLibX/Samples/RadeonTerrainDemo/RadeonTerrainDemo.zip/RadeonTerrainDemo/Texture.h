//-----------------------------------------------------------------------------
// File: Texture.h
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#ifndef _TEXTURE_H
#define _TEXTURE_H

#include <d3dx.h>
#include <tchar.h>

#define TEXTURE_PATH _T("texture\\")

class CTexture
{
	BOOL m_bHasAlpha;
	BOOL m_bMipMap;
	LPDIRECTDRAWSURFACE7 m_pddsSurface;
	TCHAR m_strFileName[256];

public:
	CTexture();
	~CTexture();
	HRESULT Create(TCHAR *strTexName, BOOL bMipMap, BOOL bAlpha);
	HRESULT Restore(LPDIRECT3DDEVICE7 pd3dDevice);
	VOID Invalidate();
	LPDIRECTDRAWSURFACE7 GetSurface();
};

#endif
