//-----------------------------------------------------------------------------
// File: Model.h
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#ifndef _MODEL_H
#define _MODEL_H

#include <d3dx.h>

class CModel
{
public:
	CModel() {};
	virtual HRESULT Load() { return S_OK; };
	virtual HRESULT Init(LPDIRECT3DDEVICE7 pd3dDevice) { return S_OK; };
	virtual VOID Destroy() {};
	virtual HRESULT Render(LPDIRECT3DDEVICE7 pd3dDevice) { return S_OK; };
	virtual DWORD CountPolys() { return 0; };
};

#endif
