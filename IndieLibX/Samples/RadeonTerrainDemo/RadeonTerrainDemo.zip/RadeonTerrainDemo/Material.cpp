//-----------------------------------------------------------------------------
// File: Material.cpp
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#define STRICT
#define D3D_OVERLOADS

#include <tchar.h>
#include <stdio.h>
#include "Helper.h"
#include "Material.h"
#include "DXErrors.h"

CMaterial::CMaterial()
{
	m_dwTexIndx = -1;
    ZeroMemory(&m_Mtrl, sizeof(D3DMATERIAL7));
}

CMaterial::~CMaterial()
{
	DeleteTexture();
}

HRESULT CMaterial::LoadMaterial(FILE *fp)
{
	HRESULT hr;
	BOOL mipmap, alpha, hasTexture;
	CHAR tname[32];
	CTexture *pTexture;

	fread(&m_Mtrl, sizeof(D3DMATERIAL7), 1, fp);
	fread(&hasTexture, sizeof(BOOL), 1, fp);
	fread(&mipmap, sizeof(BOOL), 1, fp);
	fread(&alpha, sizeof(BOOL), 1, fp);
	fread(tname, sizeof(CHAR), 32, fp);

	DeleteTexture();

	if (hasTexture)
	{
		pTexture = new CTexture();
		hr = pTexture->Create(tname, mipmap, alpha);
		if (FAILED(hr))
		{
			SAFE_DELETE(pTexture);
			return E_FAIL;
		}
		m_dwTexIndx = g_TMan.AddTexture(pTexture);
		if (m_dwTexIndx == -1)
		{
			SAFE_DELETE(pTexture);
			return E_FAIL;
		}
	}

	return S_OK;
}

HRESULT CMaterial::LoadMaterial(D3DMATERIAL7 &mtrl, TCHAR *tname, BOOL mipmap, BOOL alpha)
{
	HRESULT hr;
	CTexture *pTexture;

	m_Mtrl = mtrl;

	DeleteTexture();

	if (tname != NULL)
	{
		pTexture = new CTexture();
		hr = pTexture->Create(tname, mipmap, alpha);
		if (FAILED(hr))
		{
			SAFE_DELETE(pTexture);
			return E_FAIL;
		}
		m_dwTexIndx = g_TMan.AddTexture(pTexture);
		if (m_dwTexIndx == -1)
		{
			SAFE_DELETE(pTexture);
			return E_FAIL;
		}
	}

	return S_OK;
}

VOID CMaterial::SetMaterial(LPDIRECT3DDEVICE7 pd3dDevice)
{
	HRESULT hr;

	pd3dDevice->SetMaterial(&m_Mtrl);
	if (m_dwTexIndx != -1)
	{
		CTexture *pTexture = g_TMan.GetTexture(m_dwTexIndx);
		if (pTexture != NULL)
		{
			hr = pd3dDevice->SetTexture(0, pTexture->GetSurface());
			if (FAILED(hr))
				DD_ERR(hr);
		}
		else
			pd3dDevice->SetTexture(0, NULL);
	}
	else
		pd3dDevice->SetTexture(0, NULL);
}

VOID CMaterial::DeleteTexture()
{
	if (m_dwTexIndx != -1)
	{
		g_TMan.DeleteTexture(m_dwTexIndx);
		m_dwTexIndx = -1;
	}
}

