//-----------------------------------------------------------------------------
// File: Skydome.cpp
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

//#define STRICT
#define D3D_OVERLOADS

#include <tchar.h>
#include <stdio.h>
#include "Helper.h"
#include "Skydome.h"
#include "MManager.h"
#include "DXErrors.h"

CSkyDome::CSkyDome() : CModel()
{
	m_mSkyID = -1;
	m_mGroundID = -1;
	m_pSkyVert = NULL;
	m_pSkyVB = NULL;
	m_pGroundVert = NULL;
	m_pGroundVB = NULL;
}

CSkyDome::~CSkyDome()
{
	SAFE_DELETE(m_pSkyVert);
	SAFE_DELETE(m_pGroundVert);
	Destroy();
}

HRESULT CSkyDome::Load()
{
	FILE *fp;
	CHAR type[9];
	DWORD version;

	// Load sky model
	SAFE_DELETE(m_pSkyVert);

	if ((fp = fopen("sky.dat","rb")) == NULL)
		return E_FAIL;

	fread(type, sizeof(CHAR), 8, fp);
	fread(&version, sizeof(DWORD), 1, fp);
	type[8] = '\0';
	if (strcmp(type, "SKY_FILE"))
	{
		fclose(fp);
		return E_FAIL;
	}

	fread(&m_dwSkyNumVert, sizeof(DWORD), 1, fp);
	m_pSkyVert = new LITVERTEX[m_dwSkyNumVert];
	fread(m_pSkyVert, sizeof(LITVERTEX), m_dwSkyNumVert, fp);

	fclose(fp);

	// Load lower ground model
	SAFE_DELETE(m_pGroundVert);

	if ((fp = fopen("ground.dat","rb")) == NULL)
		return E_FAIL;

	fread(type, sizeof(CHAR), 8, fp);
	fread(&version, sizeof(DWORD), 1, fp);
	type[8] = '\0';
	if (strcmp(type, "GND_FILE"))
	{
		fclose(fp);
		return E_FAIL;
	}

	fread(&m_dwGroundNumVert, sizeof(DWORD), 1, fp);
	m_pGroundVert = new LITVERTEX[m_dwGroundNumVert];
	fread(m_pGroundVert, sizeof(LITVERTEX), m_dwGroundNumVert, fp);

	fclose(fp);

	D3DMATERIAL7 m;
	ZeroMemory(&m, sizeof(D3DMATERIAL7));
	m.dcvDiffuse.r = m.dcvAmbient.r = 1.0f;
	m.dcvDiffuse.g = m.dcvAmbient.g = 1.0f;
	m.dcvDiffuse.b = m.dcvAmbient.b = 1.0f;
	m.dcvDiffuse.a = m.dcvAmbient.a = 1.0f;

	CMaterial *mtrl;
	mtrl = new CMaterial();
	mtrl->LoadMaterial(m, _T("Sky1"), FALSE, FALSE);
	m_mSkyID = g_MMan.AddMaterial(mtrl);

	mtrl = new CMaterial();
	mtrl->LoadMaterial(m, _T("Ground"), TRUE, FALSE);
	m_mGroundID = g_MMan.AddMaterial(mtrl);

    return S_OK;
}

HRESULT CSkyDome::Init(LPDIRECT3DDEVICE7 pd3dDevice)
{
    LPLITVERTEX pvbVertices;

	if ((m_pSkyVert == NULL) || (m_pGroundVert == NULL))
		return E_FAIL;
	
	// Create and fill sky VB
	if (m_pSkyVB == NULL)
    {
		D3DVERTEXBUFFERDESC vbDesc;
		ZeroMemory(&vbDesc, sizeof(D3DVERTEXBUFFERDESC));
		vbDesc.dwSize = sizeof(D3DVERTEXBUFFERDESC);
		vbDesc.dwCaps = D3DVBCAPS_WRITEONLY;
		vbDesc.dwFVF = D3DFVF_LVERTEX1;
		vbDesc.dwNumVertices = m_dwSkyNumVert;

		D3DDEVICEDESC7 ddDesc;
		if (FAILED(pd3dDevice->GetCaps(&ddDesc)))
			return E_FAIL;

		if (!IsEqualIID(ddDesc.deviceGUID, IID_IDirect3DTnLHalDevice))
			vbDesc.dwCaps |= D3DVBCAPS_SYSTEMMEMORY;

		LPDIRECT3D7 pD3D;
		pd3dDevice->GetDirect3D(&pD3D);

		if (FAILED(pD3D->CreateVertexBuffer(&vbDesc, &m_pSkyVB, 0L)))
		{
			pD3D->Release();
			return E_FAIL;
		}
		pD3D->Release();
    }

    if (SUCCEEDED(m_pSkyVB->Lock(DDLOCK_WAIT, (VOID**)&pvbVertices, NULL)))
    {
		DWORD i;
		for(i = 0; i < m_dwSkyNumVert; i++)
        {
			pvbVertices[i] = m_pSkyVert[i];
        }
		m_pSkyVB->Unlock();
		m_pSkyVB->Optimize(pd3dDevice, 0);
    }

	// Create and fill lower ground VB
	if (m_pGroundVB == NULL)
    {
		D3DVERTEXBUFFERDESC vbDesc;
		ZeroMemory(&vbDesc, sizeof(D3DVERTEXBUFFERDESC));
		vbDesc.dwSize = sizeof(D3DVERTEXBUFFERDESC);
		vbDesc.dwCaps = D3DVBCAPS_WRITEONLY;
		vbDesc.dwFVF = D3DFVF_LVERTEX1;
		vbDesc.dwNumVertices = m_dwGroundNumVert;

		D3DDEVICEDESC7 ddDesc;
		if (FAILED(pd3dDevice->GetCaps(&ddDesc)))
			return E_FAIL;

		if (!IsEqualIID(ddDesc.deviceGUID, IID_IDirect3DTnLHalDevice))
			vbDesc.dwCaps |= D3DVBCAPS_SYSTEMMEMORY;

		LPDIRECT3D7 pD3D;
		pd3dDevice->GetDirect3D(&pD3D);

		if (FAILED(pD3D->CreateVertexBuffer(&vbDesc, &m_pGroundVB, 0L)))
		{
			pD3D->Release();
			return E_FAIL;
		}
		pD3D->Release();
    }

    if (SUCCEEDED(m_pGroundVB->Lock(DDLOCK_WAIT, (VOID**)&pvbVertices, NULL)))
    {
		DWORD i;
		for(i = 0; i < m_dwGroundNumVert; i++)
        {
			pvbVertices[i] = m_pGroundVert[i];
        }
		m_pGroundVB->Unlock();
		m_pGroundVB->Optimize(pd3dDevice, 0);
    }

    return S_OK;
}

VOID CSkyDome::Destroy()
{
	SAFE_RELEASE(m_pSkyVB);
	SAFE_RELEASE(m_pGroundVB);
}

HRESULT CSkyDome::Render(LPDIRECT3DDEVICE7 pd3dDevice)
{
	pd3dDevice->SetRenderState(D3DRENDERSTATE_ZENABLE, FALSE);
	pd3dDevice->SetRenderState(D3DRENDERSTATE_ZWRITEENABLE, FALSE);

	CMaterial *mtrl;

	pd3dDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_SELECTARG1);
	pd3dDevice->SetRenderState(D3DRENDERSTATE_CULLMODE, D3DCULL_NONE);

	pd3dDevice->SetRenderState(D3DRENDERSTATE_FOGENABLE, TRUE);
	pd3dDevice->SetRenderState(D3DRENDERSTATE_RANGEFOGENABLE, TRUE);
	pd3dDevice->SetRenderState(D3DRENDERSTATE_FOGVERTEXMODE, D3DFOG_LINEAR);
	pd3dDevice->SetRenderState(D3DRENDERSTATE_FOGTABLEMODE, D3DFOG_NONE);
	
	FLOAT start = 50000.0f;
	FLOAT end = 400000.0f;
	pd3dDevice->SetRenderState(D3DRENDERSTATE_FOGCOLOR, 0x00ADB4C7);
	pd3dDevice->SetRenderState(D3DRENDERSTATE_FOGSTART, *(DWORD*)(&start));
	pd3dDevice->SetRenderState(D3DRENDERSTATE_FOGEND, *(DWORD*)(&end));

	mtrl = g_MMan.GetMaterial(m_mGroundID);
	if (mtrl != NULL)
		mtrl->SetMaterial(pd3dDevice);
	pd3dDevice->DrawPrimitiveVB(D3DPT_TRIANGLELIST, m_pGroundVB, 0, m_dwGroundNumVert, 0L);

	mtrl = g_MMan.GetMaterial(m_mSkyID);
	if (mtrl != NULL)
		mtrl->SetMaterial(pd3dDevice);
	pd3dDevice->DrawPrimitiveVB(D3DPT_TRIANGLELIST, m_pSkyVB, 0, m_dwSkyNumVert, 0L);

	pd3dDevice->SetRenderState(D3DRENDERSTATE_FOGENABLE, FALSE);

	pd3dDevice->SetRenderState(D3DRENDERSTATE_ZENABLE, TRUE);
	pd3dDevice->SetRenderState(D3DRENDERSTATE_ZWRITEENABLE, TRUE);

	return S_OK; 
}

DWORD CSkyDome::CountPolys()
{
	return (m_dwSkyNumVert + m_dwGroundNumVert)/ 3;
}

