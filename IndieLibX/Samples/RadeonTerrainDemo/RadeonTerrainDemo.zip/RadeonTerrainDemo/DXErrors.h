//-----------------------------------------------------------------------------
// File: DXErrors.h
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#ifndef _DDERRORS_H
#define _DDERRORS_H

VOID _DbgOut(TCHAR* strFile, DWORD dwLine, HRESULT hr, TCHAR *strMsg);
VOID _ErrorOut(TCHAR *strFile, DWORD dwLine, HRESULT hr);

#if defined(DEBUG) | defined(_DEBUG)
    #define DD_ERR(hr) _ErrorOut(__FILE__, (DWORD)__LINE__, hr)
#else
    #define DD_ERR(hr)
#endif

#endif
