//-----------------------------------------------------------------------------
// File: Viewer.cpp
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#define STRICT
#define D3D_OVERLOADS

#include <tchar.h>
#include <stdio.h>
#include <math.h>
#include "Helper.h"
#include "Viewer.h"
#include "DXErrors.h"

CViewer g_Viewer;

CViewer::CViewer()
{
	D3DXVECTOR3 up = D3DXVECTOR3(0.0f, 1.0f, 0.0f);
	D3DXVECTOR3 dir = D3DXVECTOR3(0.0f, 0.0f, -1.0f);
	D3DXVECTOR3 pos = D3DXVECTOR3(0.0f, 0.0f, 0.0f);

	D3DXMatrixIdentity(&m_matRot);
}

VOID CViewer::SetAspect(FLOAT aspect)
{
	m_fAspect = aspect;
	CalculateTransform();
}

VOID CViewer::UpdateViewer(LPDIRECT3DDEVICE7 pd3dDevice, 
						   D3DXVECTOR3 &pos, D3DXQUATERNION &quat)
{
	D3DXVECTOR3 v;

	m_vPos = pos;

	D3DXMatrixRotationQuaternion(&m_matRot, &quat);
	v = D3DXVECTOR3(0.0f, 0.0f, -1.0f);
	D3DXVec3TransformCoord(&m_vDir, &v, &m_matRot);
	v = D3DXVECTOR3(0.0f, 1.0f, 0.0f);
	D3DXVec3TransformCoord(&m_vUp, &v, &m_matRot);

	D3DXMATRIX m1, m2;
	D3DXMatrixScaling(&m1, 1.0f, 1.0f, -1.0f);
	D3DXMatrixRotationX(&m2, PI / 2.0f);
	D3DXMatrixMultiply(&m2, &m1, &m2);

	D3DXVec3TransformCoord(&m_vDir, &m_vDir, &m2);
	D3DXVec3TransformCoord(&m_vUp, &m_vUp, &m2);

	m_vDir = Normalize(m_vDir);
	m_vUp = Normalize(m_vUp);
	m_vCross = Normalize(CrossProduct(m_vUp, m_vDir));
	CalculateTransform();

	pd3dDevice->SetTransform(D3DTRANSFORMSTATE_PROJECTION, (D3DMATRIX*)m_matProj);
	pd3dDevice->SetTransform(D3DTRANSFORMSTATE_VIEW, (D3DMATRIX*)m_matView);
}

D3DXVECTOR3& CViewer::GetPos()
{
	return m_vPos;
}

VOID CViewer::CalculateTransform()
{
	D3DXMatrixPerspectiveFovLH(&m_matProj, FOV, m_fAspect, NEAR_CLIP, 1200000.0f);

	ComputeViewMatrix(&m_matView, &m_vPos, &m_vDir, &m_vUp);
}

VOID CViewer::ComputeClipVolume(CLIPVOLUME& cv)
{
	FLOAT dist, t;
	D3DXVECTOR3 p, pt[8];
	D3DXVECTOR3 v1, v2, n;

	for(INT i = 0; i < 8; i++)
	{
		dist = (i & 0x4) ? FAR_CLIP : NEAR_CLIP;
		pt[i].x = dist * m_vDir.x;
		pt[i].y = dist * m_vDir.y;
		pt[i].z = dist * m_vDir.z;
		t = dist * tanf(FOV);
		t = (i & 0x2) ? t : -t;
		pt[i].x += m_vUp.x * t;
		pt[i].y += m_vUp.y * t;
		pt[i].z += m_vUp.z * t;
		t = dist * tanf(FOV) / m_fAspect; // take into account screen proportions
		t = (i & 0x1) ? -t : t;
		pt[i].x += m_vCross.x * t;
		pt[i].y += m_vCross.y * t;
		pt[i].z += m_vCross.z * t;
		pt[i].x = m_vPos.x + pt[i].x;
		pt[i].y = m_vPos.y + pt[i].y;
		pt[i].z = m_vPos.z + pt[i].z;
	}
	//compute the near plane
	v1.x = pt[2].x - pt[0].x;
	v1.y = pt[2].y - pt[0].y;
	v1.z = pt[2].z - pt[0].z;
	v2.x = pt[1].x - pt[0].x;
	v2.y = pt[1].y - pt[0].y;
	v2.z = pt[1].z - pt[0].z;
	n = Normalize(CrossProduct(v2, v1));
	cv.pNear.a = n.x;
	cv.pNear.b = n.y;
	cv.pNear.c = n.z;
	cv.pNear.d = -(n.x * pt[0].x + n.y * pt[0].y + n.z * pt[0].z);

	//compute the far plane
	v1.x = pt[5].x - pt[4].x;
	v1.y = pt[5].y - pt[4].y;
	v1.z = pt[5].z - pt[4].z;
	v2.x = pt[6].x - pt[4].x;
	v2.y = pt[6].y - pt[4].y;
	v2.z = pt[6].z - pt[4].z;
	n = Normalize(CrossProduct(v2, v1));
	cv.pFar.a = n.x;
	cv.pFar.b = n.y;
	cv.pFar.c = n.z;
	cv.pFar.d = -(n.x * pt[4].x + n.y * pt[4].y + n.z * pt[4].z);

	//compute the top plane
	v1.x = pt[6].x - pt[2].x;
	v1.y = pt[6].y - pt[2].y;
	v1.z = pt[6].z - pt[2].z;
	v2.x = pt[3].x - pt[2].x;
	v2.y = pt[3].y - pt[2].y;
	v2.z = pt[3].z - pt[2].z;
	n = Normalize(CrossProduct(v2, v1));
	cv.pTop.a = n.x;
	cv.pTop.b = n.y;
	cv.pTop.c = n.z;
	cv.pTop.d = -(n.x * pt[2].x + n.y * pt[2].y + n.z * pt[2].z);

	//compute the bottom plane
	v1.x = pt[1].x - pt[0].x;
	v1.y = pt[1].y - pt[0].y;
	v1.z = pt[1].z - pt[0].z;
	v2.x = pt[4].x - pt[0].x;
	v2.y = pt[4].y - pt[0].y;
	v2.z = pt[4].z - pt[0].z;
	n = Normalize(CrossProduct(v2, v1));
	cv.pBottom.a = n.x;
	cv.pBottom.b = n.y;
	cv.pBottom.c = n.z;
	cv.pBottom.d = -(n.x * pt[0].x + n.y * pt[0].y + n.z * pt[0].z);

	//compute the left plane
	v1.x = pt[3].x - pt[1].x;
	v1.y = pt[3].y - pt[1].y;
	v1.z = pt[3].z - pt[1].z;
	v2.x = pt[5].x - pt[1].x;
	v2.y = pt[5].y - pt[1].y;
	v2.z = pt[5].z - pt[1].z;
	n = Normalize(CrossProduct(v2, v1));
	cv.pLeft.a = n.x;
	cv.pLeft.b = n.y;
	cv.pLeft.c = n.z;
	cv.pLeft.d = -(n.x * pt[1].x + n.y * pt[1].y + n.z * pt[1].z);

	//compute the right plane
	v1.x = pt[4].x - pt[0].x;
	v1.y = pt[4].y - pt[0].y;
	v1.z = pt[4].z - pt[0].z;
	v2.x = pt[2].x - pt[0].x;
	v2.y = pt[2].y - pt[0].y;
	v2.z = pt[2].z - pt[0].z;
	n = Normalize(CrossProduct(v2, v1));
	cv.pRight.a = n.x;
	cv.pRight.b = n.y;
	cv.pRight.c = n.z;
	cv.pRight.d = -(n.x * pt[0].x + n.y * pt[0].y + n.z * pt[0].z);
}
