//-----------------------------------------------------------------------------
// File: TerrainApp.cpp
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#define STRICT

#include <windows.h>
#include <tchar.h>
#include <mmsystem.h>
#include <stdio.h>
#include <d3dx.h>
#include "resource.h"
#include "Helper.h"
#include "DXErrors.h"
#include "TerrainApp.h"
#include "TManager.h"
#include "MManager.h"
#include "Viewer.h"

CTerrainApp g_App;

LRESULT CALLBACK WndProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	return g_App.WndProc(hwnd, uMsg, wParam, lParam);
}

INT PASCAL WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, 
    LPSTR lpszCmdLine, INT nCmdShow) 
{
	HRESULT hr;

	hr = g_App.Run(hInstance, hPrevInstance, lpszCmdLine, nCmdShow);
	if (FAILED(hr))
		return -1;

	return 0;
}

CTerrainApp::CTerrainApp()
{
	m_pD3DX = NULL;
	m_pDD = NULL;
	m_pD3D = NULL;
	m_pd3dDevice = NULL;
	m_bInitialized = FALSE;
	m_bActive = FALSE;
	m_strAppName = _T("D3D Terrain Demo");
	m_dwFSWidth = 640;
	m_dwFSHeight = 480;
	m_bShowingDemo = FALSE;
	m_bNoTnL = FALSE;
	m_bWindowed = FALSE;

	m_pFlyDemo = new CFlyDemo();
	m_pSplash = new CSplashScreen();
}

CTerrainApp::~CTerrainApp()
{
	SAFE_DELETE(m_pFlyDemo);
	SAFE_DELETE(m_pSplash);
}

HRESULT CTerrainApp::InitApplication(HINSTANCE hInstance)
{
	WNDCLASS wc;

	wc.style = 0; 
	wc.lpfnWndProc = (WNDPROC)::WndProc; 
	wc.cbClsExtra = 0; 
	wc.cbWndExtra = 0; 
	wc.hInstance = hInstance; 
	wc.hIcon = LoadIcon(hInstance, MAKEINTRESOURCE(IDI_MAIN_ICON));
	wc.hCursor = (HCURSOR)NULL;
	wc.hbrBackground = (HBRUSH)GetStockObject(BLACK_BRUSH); 
	wc.lpszMenuName =  NULL;
	wc.lpszClassName = m_strAppName; 

	if (RegisterClass(&wc)) 
		return S_OK;

	return E_FAIL;
}

HRESULT CTerrainApp::InitInstance(HINSTANCE hInstance, INT nCmdShow)
{
	// Create window
	if (m_bWindowed)
	{
		m_hWnd = CreateWindow(m_strAppName,
			m_strAppName,
			WS_OVERLAPPEDWINDOW,
			CW_USEDEFAULT,
			CW_USEDEFAULT,
			m_dwFSWidth,
			m_dwFSHeight,
			(HWND)NULL,
			(HMENU)NULL,
			hInstance,
			(LPVOID)NULL); 
	}
	else
	{
		m_hWnd = CreateWindow(m_strAppName,
			m_strAppName,
			WS_POPUP,
			CW_USEDEFAULT,
			CW_USEDEFAULT,
			m_dwFSWidth,
			m_dwFSHeight,
			(HWND)NULL,
			(HMENU)NULL,
			hInstance,
			(LPVOID)NULL); 
	}

    // If the main window cannot be created, terminate 
    // the application. 
	if (m_hWnd == NULL) 
		return E_FAIL;

    ShowWindow(m_hWnd, nCmdShow);
    UpdateWindow(m_hWnd);

	return S_OK;
}

HRESULT CTerrainApp::ParseCommandLine(LPSTR lpszCmdLine)
{
	// Parse command line
	CHAR *psz, *pszLim;

	psz = lpszCmdLine;
	pszLim = psz + strlen(psz);

	while (psz < pszLim)
	{        
		CHAR *pszWord;
		pszWord = psz;

		while ((psz[0] != '\0') && (psz[0] != ' '))
			psz++;

		psz[0] = '\0';
		psz++;

		if ((strcmp(pszWord, "640x480") == 0) || (strcmp(pszWord, "640X480") == 0))
		{
			m_dwFSWidth = 640;
			m_dwFSHeight = 480;
			break;
		}
		if ((strcmp(pszWord, "800x600") == 0) || (strcmp(pszWord, "800X600") == 0))
		{
			m_dwFSWidth = 800;
			m_dwFSHeight = 600;
			break;
		}
		if ((strcmp(pszWord, "1024x768") == 0) || (strcmp(pszWord, "1024X768") == 0))
		{
			m_dwFSWidth = 1024;
			m_dwFSHeight = 768;
			break;
		}
		if ((strcmp(pszWord, "1280x1024") == 0) || (strcmp(pszWord, "1280X1024") == 0))
		{
			m_dwFSWidth = 1280;
			m_dwFSHeight = 1024;
			break;
		}
		if ((strcmp(pszWord, "1600x1200") == 0) || (strcmp(pszWord, "1600X1200") == 0))
		{
			m_dwFSWidth = 1600;
			m_dwFSHeight = 1200;
			break;
		}

		if ((strcmp(pszWord, "-notnl") == 0) || (strcmp(pszWord, "-NOTNL") == 0))
		{
			m_bNoTnL = TRUE;
			break;
		}
		if ((strcmp(pszWord, "-win") == 0) || (strcmp(pszWord, "-WIN") == 0))
		{
			m_bWindowed = TRUE;
			break;
		}

		while ((psz < pszLim) && (psz[0] == ' '))
			psz++;
	}

	return S_OK;
}

HRESULT CTerrainApp::InitializeD3DX()
{
	HRESULT hr;

    hr = D3DXInitialize();
	if (FAILED(hr))
	{
		DD_ERR(hr);
		return E_FAIL;
	}
	
	DWORD dwAcceleration;
	if (m_bNoTnL)
		dwAcceleration = D3DX_HWLEVEL_RASTER;
	else
		dwAcceleration = D3DX_HWLEVEL_TL;

	if (m_bWindowed)
	{
		hr = D3DXCreateContextEx(dwAcceleration,	// D3DX handle
			0,			// flags
			m_hWnd,
			NULL,
			D3DX_DEFAULT,						// colorbits
			D3DX_DEFAULT, // alphabits
			D3DX_DEFAULT,									// numdepthbits
			D3DX_DEFAULT, // stencil bits
			D3DX_DEFAULT, // backbuffers
			D3DX_DEFAULT,
			D3DX_DEFAULT,
			D3DX_DEFAULT, // refresh rate
			&m_pD3DX);							// returned D3DX interface

	}
	else
	{
		hr = D3DXCreateContextEx(dwAcceleration,	// D3DX handle
			D3DX_CONTEXT_FULLSCREEN,			// flags
			m_hWnd,
			NULL,
			32,									// colorbits
			D3DX_DEFAULT, // alphabits
			D3DX_DEFAULT,									// numdepthbits
			D3DX_DEFAULT, // stencil bits
			1, // backbuffers
			m_dwFSWidth,
			m_dwFSHeight,
			D3DX_DEFAULT, // refresh rate
			&m_pD3DX);							// returned D3DX interface
	}
	if (FAILED(hr))
	{
		DD_ERR(hr);
		return E_FAIL;
	}

	hr = InitRenderer();
	if (FAILED(hr))
		return E_FAIL;

	g_TMan.RestoreAll(m_pd3dDevice);

	if (m_bShowingDemo)
	{
		if ((m_pFlyDemo != NULL) && (m_pFlyDemo->m_bLoaded))
			m_pFlyDemo->Init(m_pd3dDevice);
	}
	else
	{
		if ((m_pSplash != NULL) && (m_pSplash->m_bLoaded))
			m_pSplash->Init(m_pd3dDevice);
	}

	m_bInitialized = TRUE;
	return S_OK;
}

HRESULT CTerrainApp::UnInitializeD3DX()
{
	HRESULT hr;

	if (m_bShowingDemo)
	{
		if ((m_pFlyDemo != NULL) && (m_pFlyDemo->m_bLoaded))
			m_pFlyDemo->Destroy();
	}
	else
	{
		if ((m_pSplash != NULL) && (m_pSplash->m_bLoaded))
			m_pSplash->Destroy();
	}

	g_TMan.InvalidateAll();

	SAFE_RELEASE(m_pd3dDevice);
	SAFE_RELEASE(m_pD3D);
	SAFE_RELEASE(m_pDD);
	SAFE_RELEASE(m_pD3DX);

	hr = D3DXUninitialize();
	if (FAILED(hr))
	{
		DD_ERR(hr);
		return E_FAIL;
	}

	return S_OK;
}

HRESULT CTerrainApp::InitRenderer()
{
	HRESULT hr;

	m_pDD = m_pD3DX->GetDD();
    if (m_pDD == NULL)
	{
		DD_ERR(-1);
		return E_FAIL;
	}

	m_pD3D = m_pD3DX->GetD3D();
    if (m_pD3D == NULL)
	{
		DD_ERR(-1);
		return E_FAIL;
	}

	m_pd3dDevice = m_pD3DX->GetD3DDevice();
	if (m_pd3dDevice == NULL)
	{
		DD_ERR(-1);
		return E_FAIL;
	}

	hr = m_pD3DX->SetClearColor(D3DRGBA(0.0f, 0.0f, 0.0f, 0.0f));
	if (FAILED(hr))
	{
		DD_ERR(hr);
		return E_FAIL;
	}

	hr = m_pD3DX->Clear(D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER);
	if (FAILED(hr))
	{
		DD_ERR(hr);
		return E_FAIL;
	}

	D3DVIEWPORT7 vp;
    m_pd3dDevice->GetViewport(&vp);
    FLOAT fAspect = ((FLOAT)vp.dwHeight) / (FLOAT)vp.dwWidth;
	g_Viewer.SetAspect(fAspect);

	D3DXMATRIX mat;
	D3DXMatrixIdentity(&mat);
	m_pd3dDevice->SetTransform(D3DTRANSFORMSTATE_WORLD, (D3DMATRIX*)mat);

	return S_OK;
}

HRESULT CTerrainApp::RestoreContext()
{
	HRESULT hr;
    
	hr = m_pD3DX->RestoreSurfaces();
	if (FAILED(hr))
	{
		DD_ERR(hr);
        return E_FAIL;
	}

	g_TMan.InvalidateAll();
	g_TMan.RestoreAll(m_pd3dDevice);

	if (m_bShowingDemo)
	{
		if ((m_pFlyDemo != NULL) && (m_pFlyDemo->m_bLoaded))
		{
			m_pFlyDemo->Destroy();
			m_pFlyDemo->Init(m_pd3dDevice);
		}
	}
	else
	{
		if ((m_pSplash != NULL) && (m_pSplash->m_bLoaded))
			m_pSplash->Init(m_pd3dDevice);
	}

	return S_OK;
}

HRESULT CTerrainApp::Startup()
{
	HRESULT hr;

	if (FAILED(g_MMan.Load("material.dat")))
		return E_FAIL;

	if (m_pSplash != NULL)
	{
		hr = m_pSplash->Load();
		if (FAILED(hr) || (!m_pSplash->m_bLoaded))
			return E_FAIL;
		hr = m_pSplash->Init(m_pd3dDevice);
		if (FAILED(hr))
			return E_FAIL;

		g_TMan.RestoreAll(m_pd3dDevice);
	}
	else
		return E_FAIL;

	return S_OK;
}

LRESULT CTerrainApp::WndProc(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{
	switch (uMsg)
	{
	case WM_ACTIVATEAPP:
		{
			SetActive((BOOL)wParam);
		} break;
	case WM_CLOSE:
		{
			PostQuitMessage(0);
		} break;
	case WM_KEYUP:
		switch (wParam)
		{
		case VK_ESCAPE:
			{
				PostQuitMessage(0);
			} break;
		case 'W':
			{
				if (m_bShowingDemo && (m_pFlyDemo != NULL))
					m_pFlyDemo->ToggleWireframe();

			} break;
		} break;
	case WM_SETCURSOR:
		{
			SetCursor(NULL);
		} break;
	case WM_POWERBROADCAST:
		switch (wParam)
		{
		case PBT_APMQUERYSUSPEND:
			{
				// Going into suspended mode
				SetActive(FALSE);
			} break;
		case PBT_APMRESUMESUSPEND:
			{
				// Recovering from suspended mode
				SetActive(TRUE);
			} break;
		} break;
	};

	return DefWindowProc(hwnd, uMsg, wParam, lParam);
}

HRESULT CTerrainApp::MessageLoop()
{
	BOOL bGotMsg;
	MSG msg;
	HRESULT hr;

	PeekMessage(&msg, NULL, 0U, 0U, PM_NOREMOVE);
	while (msg.message != WM_QUIT)
	{
		bGotMsg = PeekMessage(&msg, NULL, 0U, 0U, PM_REMOVE);
		if (bGotMsg)
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}
		else
		{
			if (m_bActive)
			{
				UpdateTime();
				hr = Draw();
				if (FAILED(hr))
                {
					DD_ERR(hr);
					m_bInitialized = FALSE;
					PostQuitMessage(0);
				}
			}
			else
				WaitMessage();
		}
		if (m_bShowingDemo && (!m_pFlyDemo->m_bLoaded))
		{
			if (m_pFlyDemo != NULL)
			{
				hr = m_pFlyDemo->Load();
				if (FAILED(hr) || (!m_pFlyDemo->m_bLoaded))
					return E_FAIL;
				hr = m_pFlyDemo->Init(m_pd3dDevice);
				if (FAILED(hr))
					return E_FAIL;

				g_TMan.RestoreAll(m_pd3dDevice);
				StartTime();
				m_dwLastPerfTime = m_dwStartTime;
				m_dwFPS = 0;
				m_dwPPS = 0;
				m_dwLoopCount = 0;
				m_strStats[0] = '\0';
			}
			else
				return E_FAIL;
		}
	}

	return S_OK;
}

VOID CTerrainApp::SetActive(BOOL bActive)
{
	if (bActive)
	{
		ShowCursor(FALSE);
	}
	else
	{
		if (m_pDD) m_pDD->FlipToGDISurface();
		DrawMenuBar(m_hWnd);
		RedrawWindow(m_hWnd, NULL, NULL, RDW_FRAME);
		ShowCursor(TRUE);
	}

	m_bActive = bActive;
}

VOID CTerrainApp::StartTime()
{
	m_dwStartTime = timeGetTime();
}

VOID CTerrainApp::UpdateTime()
{
	DWORD time = timeGetTime();

	if (!m_bActive)
		m_dwStartTime += time - m_dwTime;
	m_dwTime = time;
}

HRESULT CTerrainApp::Draw()
{
	HRESULT hr;

	hr = DrawFrame();
	if (FAILED(hr))
	{
		return E_FAIL;
	}

	// Update frame
	hr = m_pD3DX->UpdateFrame(0);
	if (DDERR_SURFACELOST == hr || DDERR_SURFACEBUSY == hr)
	{
		hr = m_pDD->TestCooperativeLevel();
		if (SUCCEEDED(hr))
		{
			hr = RestoreContext();
			if (FAILED(hr))
			{
				DD_ERR(hr);
				return E_FAIL;
			}
		}
		else if (DDERR_WRONGMODE == hr)
		{
			hr = UnInitializeD3DX();
			if (FAILED(hr))
			{
				DD_ERR(hr);
				return E_FAIL;
			}
			hr = InitializeD3DX();
			if (FAILED(hr))
			{
				DD_ERR(hr);
				return E_FAIL;
			}
		}
		else
			return E_FAIL;

		hr = DrawFrame();
		if (FAILED(hr))
		{
			return E_FAIL;
		}
		hr = m_pD3DX->UpdateFrame(0);
		if (FAILED(hr))
		{
			DD_ERR(hr);
			return E_FAIL;
		}
	}

	return S_OK;
}

HRESULT CTerrainApp::DrawFrame()
{
	if (!m_bInitialized)
		return E_FAIL;

	if (SUCCEEDED(m_pd3dDevice->BeginScene()))
	{
		m_pd3dDevice->Clear(0, NULL, /*D3DCLEAR_TARGET |*/ D3DCLEAR_ZBUFFER,
			0x00000000, 1.0f, 0);

		FLOAT fTime = (FLOAT)(m_dwTime - m_dwStartTime) / 1000.0f;
		if (m_bShowingDemo && m_pFlyDemo->m_bLoaded)
		{
			m_pFlyDemo->Render(fTime, m_pd3dDevice);
			m_dwFPS++;
			m_dwLoopFrames++;
			m_dwPPS += m_pFlyDemo->CountPolys();

			if (m_dwTime - m_dwLastPerfTime > 1000.0)
			{
				sprintf(m_strStats, "Framerate: %d fps, polygon count: %.3f Mpps", m_dwFPS,
					(FLOAT)m_dwPPS / 1000000.0);
				m_dwFPS = 0;
				m_dwPPS = 0;
				m_dwLastPerfTime = m_dwTime;
			}
			m_pD3DX->DrawDebugText(0.01f, 0.0f, 0x00ffff80, m_strStats);
		}
		else if (m_pSplash->m_bLoaded)
		{
			m_pSplash->Render(fTime, m_pd3dDevice);
			if ((FLOAT)(m_dwTime - m_dwStartTime) / 1000.0f > 1.0f)
				m_bShowingDemo = TRUE;
		}
		m_pd3dDevice->EndScene();
	}

	return S_OK;
}

HRESULT CTerrainApp::Run(HINSTANCE hInstance, HINSTANCE hPrevInstance, 
    LPSTR lpszCmdLine, INT nCmdShow)
{
	HRESULT hr;

	hr = ParseCommandLine(lpszCmdLine);
	if (FAILED(hr))
		return E_FAIL;

	if (!hPrevInstance)
	{
		hr = InitApplication(hInstance);
		if (FAILED(hr))
			return E_FAIL;
	}

	hr = InitInstance(hInstance, nCmdShow);
	if (FAILED(hr)) 
		return E_FAIL;

	hr = InitializeD3DX();
	if (FAILED(hr))
		return E_FAIL;

	hr = Startup();
	if (FAILED(hr))
	{
		m_bInitialized = FALSE;
	}

	if (m_bInitialized)
	{
		StartTime();
		MessageLoop();
	}

	hr = UnInitializeD3DX();
	if (FAILED(hr))
	{
		return E_FAIL;
	}

	return S_OK;
}
