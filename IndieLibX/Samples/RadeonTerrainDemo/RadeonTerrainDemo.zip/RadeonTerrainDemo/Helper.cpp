//-----------------------------------------------------------------------------
// File: Helper.cpp
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#include <d3dx.h>
#include "Helper.h"

// D3DXMatrixLookAtLH is broken, so use our own routine
void ComputeViewMatrix(D3DXMATRIX *matView, D3DXVECTOR3 *vEye, D3DXVECTOR3 *vDir, D3DXVECTOR3 *vUp)
{
	*vUp = *vUp - (D3DXVec3Dot(vDir, vUp) * *vDir);
	D3DXVec3Normalize(vUp, vUp);
	D3DXVECTOR3 vCross;
	D3DXVec3Cross(&vCross, vUp, vDir);

	D3DXMatrixIdentity(matView);
	matView->m[0][0] = vCross.x;  matView->m[0][1] = vUp->x;  matView->m[0][2] = vDir->x;
	matView->m[1][0] = vCross.y;  matView->m[1][1] = vUp->y;  matView->m[1][2] = vDir->y;
	matView->m[2][0] = vCross.z;  matView->m[2][1] = vUp->z;  matView->m[2][2] = vDir->z;

	matView->m[3][0] = -D3DXVec3Dot(vEye, &vCross);
	matView->m[3][1] = -D3DXVec3Dot(vEye, vUp);
	matView->m[3][2] = -D3DXVec3Dot(vEye, vDir);
}
