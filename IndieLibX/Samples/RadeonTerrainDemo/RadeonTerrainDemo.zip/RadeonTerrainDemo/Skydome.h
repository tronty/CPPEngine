//-----------------------------------------------------------------------------
// File: Skydome.h
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#ifndef _SKYDOME_H
#define _SKYDOME_H

#include <d3dx.h>
#include "Model.h"
#include "Material.h"
#include "LitVertex.h"

class CSkyDome : public CModel
{
	DWORD m_mSkyID;
	DWORD m_mGroundID;
	// Sky mesh
	LPLITVERTEX m_pSkyVert;
	DWORD m_dwSkyNumVert;
	LPDIRECT3DVERTEXBUFFER7 m_pSkyVB;
	// Ground mesh
	LPLITVERTEX m_pGroundVert;
	DWORD m_dwGroundNumVert;
	LPDIRECT3DVERTEXBUFFER7 m_pGroundVB;

public:
	CSkyDome();
	~CSkyDome();
	HRESULT Load();
	HRESULT Init(LPDIRECT3DDEVICE7 pd3dDevice);
	VOID Destroy();
	HRESULT Render(LPDIRECT3DDEVICE7 pd3dDevice);
	DWORD CountPolys();
};

#endif
