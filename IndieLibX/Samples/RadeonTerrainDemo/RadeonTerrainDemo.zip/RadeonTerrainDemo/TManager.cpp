//-----------------------------------------------------------------------------
// File: TManager.cpp
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#define STRICT
#define D3D_OVERLOADS

#include <tchar.h>
#include <stdio.h>
#include "Helper.h"
#include "TManager.h"
#include "DXErrors.h"

CTextureManager g_TMan;

CTextureManager::CTextureManager()
{
	ZeroMemory(m_Textures, sizeof(m_Textures));
}

CTextureManager::~CTextureManager()
{
	for(DWORD i = 0; i < MAX_TEXTURES; i++)
	{
		DeleteTexture(i);
	}
}

CTexture *CTextureManager::GetTexture(DWORD n)
{
	if (n >= MAX_TEXTURES)
		return NULL;
	return m_Textures[n];
}

DWORD CTextureManager::AddTexture(CTexture *texture)
{
	for(DWORD i = 0; i < MAX_TEXTURES; i++)
	{
		if (m_Textures[i] == NULL)
		{
			m_Textures[i] = texture;
			return i;
		}
	}
	return -1;
}

HRESULT CTextureManager::DeleteTexture(DWORD n)
{
	if (n >= MAX_TEXTURES)
		return E_FAIL;
	SAFE_DELETE(m_Textures[n]);

	return S_OK;
}

HRESULT CTextureManager::RestoreAll(LPDIRECT3DDEVICE7 pd3dDevice)
{
	for(DWORD i = 0; i < MAX_TEXTURES; i++)
	{
		if (m_Textures[i] != NULL)
		{
			if (FAILED(m_Textures[i]->Restore(pd3dDevice)))
				return E_FAIL;
		}
	}

	return S_OK;
}

VOID CTextureManager::InvalidateAll()
{
	for(DWORD i = 0; i < MAX_TEXTURES; i++)
	{
		if (m_Textures[i] != NULL)
		{
			m_Textures[i]->Invalidate();
		}
	}
}

