//-----------------------------------------------------------------------------
// File: SplashScreen.h
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#ifndef _SPLASHSCREEN_H
#define _SPLASHSCREEN_H

#include <d3dx.h>
#include "Demo.h"

class CSplashScreen : public CDemo
{
private:
	BOOL m_bFinished;
	D3DVERTEX m_vMesh[4];
	DWORD m_dwTexIndx; // -1 if not loaded

	VOID DeleteTexture();

public:
	CSplashScreen();
	~CSplashScreen();
	HRESULT Load();
	HRESULT Init(LPDIRECT3DDEVICE7 pd3dDevice);
	VOID Destroy();
	HRESULT Render(FLOAT fTime, LPDIRECT3DDEVICE7 pd3dDevice);
};

#endif
