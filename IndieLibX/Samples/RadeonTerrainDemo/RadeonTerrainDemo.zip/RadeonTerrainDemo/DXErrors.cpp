//-----------------------------------------------------------------------------
// File: DXErrors.cpp
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#include <windows.h>
#include <tchar.h>
#include <d3dx.h>

VOID _DbgOut(TCHAR* strFile, DWORD dwLine, HRESULT hr, TCHAR *strMsg)
{
	TCHAR buffer[256];

	wsprintf(buffer, _T("%s(%ld): "), strFile, dwLine);
	OutputDebugString(buffer);
	OutputDebugString(strMsg);
	if (hr)
	{
		wsprintf(buffer, _T("(hr=%08lx)\n"), hr);
		OutputDebugString(buffer);
	}
	OutputDebugString(_T("\n"));
}

VOID _ErrorOut(TCHAR *strFile, DWORD dwLine, HRESULT hr)
{
	TCHAR strErr[100];

	D3DXGetErrorString(hr, 100, strErr);
	_DbgOut(strFile, dwLine, hr, strErr);
}
