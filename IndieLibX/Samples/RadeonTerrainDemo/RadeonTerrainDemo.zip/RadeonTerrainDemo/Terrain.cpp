//-----------------------------------------------------------------------------
// File: Terrain.cpp
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#define STRICT
#define D3D_OVERLOADS

#include <tchar.h>
#include <stdio.h>
#include "Helper.h"
#include "Terrain.h"
#include "Viewer.h"
#include "DXErrors.h"

#define SFC_SIGN "SFC_FILE"

CTerrain::CTerrain() : CModel()
{
	m_pOT = NULL;
	m_pVS = NULL;
	m_pRQ = new CRenderQueue();
//	m_bDetailTexture = FALSE;
}

CTerrain::~CTerrain()
{
	SAFE_DELETE(m_pOT);
	SAFE_DELETE(m_pVS);
	SAFE_DELETE(m_pRQ);
}

HRESULT CTerrain::Load()
{
	FILE *fp;
	CHAR signature[9];
	DWORD version;

	if ((fp = fopen("terrain.dat", "rb")) == NULL)
		return E_FAIL;

	fread(signature, sizeof(CHAR), 8, fp);
	signature[8]='\0';
	fread(&version, sizeof(DWORD), 1, fp);
	
	if (strcmp(signature, SFC_SIGN))
	{
		fclose(fp);
		return E_FAIL;
	}

	m_pVS = new CVertexStore(fp);
	m_pOT = new COctreeNode(fp);

	fclose(fp);

	return S_OK;
}

HRESULT CTerrain::Init(LPDIRECT3DDEVICE7 pd3dDevice)
{
	return m_pVS->Init(pd3dDevice);
}

VOID CTerrain::Destroy()
{
	m_pVS->Destroy();
}

HRESULT CTerrain::Render(LPDIRECT3DDEVICE7 pd3dDevice)
{
	if (m_pOT != NULL)
	{
		CLIPVOLUME cv;
		D3DXVECTOR3 pos = g_Viewer.GetPos();

		g_Viewer.ComputeClipVolume(cv);
		m_pRQ->ClearQueue();
		m_pOT->Cull(m_pRQ, cv, pos);
		
		pd3dDevice->SetRenderState(D3DRENDERSTATE_FOGENABLE, TRUE);
		pd3dDevice->SetRenderState(D3DRENDERSTATE_RANGEFOGENABLE, TRUE);
		pd3dDevice->SetRenderState(D3DRENDERSTATE_FOGVERTEXMODE, D3DFOG_LINEAR);
		pd3dDevice->SetRenderState(D3DRENDERSTATE_FOGTABLEMODE, D3DFOG_NONE);
	
		FLOAT start = 50000.0f;
		FLOAT end = 400000.0f;
		pd3dDevice->SetRenderState(D3DRENDERSTATE_FOGCOLOR, 0x00ADB4C7);
		pd3dDevice->SetRenderState(D3DRENDERSTATE_FOGSTART, *(DWORD*)(&start));
		pd3dDevice->SetRenderState(D3DRENDERSTATE_FOGEND, *(DWORD*)(&end));

		pd3dDevice->SetRenderState(D3DRENDERSTATE_CULLMODE, D3DCULL_CW);
		pd3dDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_MODULATE);

		m_pRQ->Render(pd3dDevice, m_pVS);

		pd3dDevice->SetRenderState(D3DRENDERSTATE_FOGENABLE, FALSE);
	}
	return S_OK;
}

DWORD CTerrain::CountPolys()
{
	return m_pRQ->CountPolys();
}
