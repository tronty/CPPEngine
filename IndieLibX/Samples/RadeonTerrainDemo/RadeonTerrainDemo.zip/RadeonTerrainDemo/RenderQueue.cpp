//-----------------------------------------------------------------------------
// File: RenderQueue.cpp
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#define STRICT
#define D3D_OVERLOADS

#include <tchar.h>
#include <stdio.h>
#include <memory.h>
#include "Helper.h"
#include "RenderQueue.h"
#include "DXErrors.h"

CRenderQueue::CRenderQueue()
{
	for(DWORD i = 0; i < MAX_MATERIALS; i++)
	{
		for(DWORD j = 0; j < MAX_VB_QUEUES; j++)
		{
			m_Queues[i][j].pLists = new CTriangleList* [MAX_QUEUE_SIZE];
		}
	}
}

CRenderQueue::~CRenderQueue()
{
	for(DWORD i = 0; i < MAX_MATERIALS; i++)
	{
		for(DWORD j = 0; j < MAX_VB_QUEUES; j++)
		{
			SAFE_DELETE_ARRAY(m_Queues[i][j].pLists);
		}
	}
}

VOID CRenderQueue::ClearQueue()
{
	for(DWORD i = 0; i < MAX_MATERIALS; i++)
	{
		for(DWORD j = 0; j < MAX_VB_QUEUES; j++)
		{
			m_Queues[i][j].dwVBID = -1;
			m_Queues[i][j].dwListCount = 0;
		}
	}
	ZeroMemory(m_dwVBQueueCount, sizeof(m_dwVBQueueCount));
}

HRESULT CRenderQueue::AddToQueue(CTriangleList *tlist)
{
	DWORD mID = tlist->m_dwMaterialID;
	DWORD vbID = tlist->m_dwVBID;
	DWORD i;

	BOOL queueFound = FALSE;
	for(i = 0; i < m_dwVBQueueCount[mID]; i++)
	{
		if (m_Queues[mID][i].dwVBID == vbID)
		{
			queueFound = TRUE;
			break;
		}
	}

	if (!queueFound)
	{
		i = m_dwVBQueueCount[mID]++;
		m_Queues[mID][i].dwVBID = vbID;
	}

	// Batch by VB and material
	m_Queues[mID][i].pLists[m_Queues[mID][i].dwListCount++] = tlist;

	return S_OK;
}

HRESULT CRenderQueue::Render(LPDIRECT3DDEVICE7 pd3dDevice, CVertexStore *pVS)
{
	CTriangleList **lists;

	for(DWORD i = 0; i < MAX_QUEUES; i++)
	{
		if (m_dwVBQueueCount[i] > 0)
			g_MMan.GetMaterial(i)->SetMaterial(pd3dDevice);

		for(DWORD j = 0; j < m_dwVBQueueCount[i]; j++)
		{
			lists = m_Queues[i][j].pLists;
			for(DWORD k = 0; k < m_Queues[i][j].dwListCount; k++)
			{
				lists[k]->Render(pd3dDevice, pVS);
			}

		}
	}

	return S_OK;
}

DWORD CRenderQueue::CountPolys()
{
	DWORD dwCount = 0;
	CTriangleList **lists;

	for(DWORD i = 0; i < MAX_QUEUES; i++)
	{
		for(DWORD j = 0; j < m_dwVBQueueCount[i]; j++)
		{
			lists = m_Queues[i][j].pLists;
			for(DWORD k = 0; k < m_Queues[i][j].dwListCount; k++)
				dwCount += lists[k]->m_dwIndNum;
		}
	}

	return dwCount / 3;
}
