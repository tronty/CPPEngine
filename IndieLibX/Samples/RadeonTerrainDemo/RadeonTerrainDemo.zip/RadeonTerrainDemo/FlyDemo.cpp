//-----------------------------------------------------------------------------
// File: FlyDemo.cpp
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#define STRICT
#define D3D_OVERLOADS

#include <tchar.h>
#include <stdio.h>
#include "Helper.h"
#include "FlyDemo.h"
#include "Viewer.h"
#include "DXErrors.h"


CFlyDemo::CFlyDemo() : CDemo()
{
	m_pSky = new CSkyDome();
	m_pTerrain = new CTerrain();
	m_pPath = new CPath();

	m_bLoaded = FALSE;
	m_bInitialized = FALSE;
}

CFlyDemo::~CFlyDemo()
{
	SAFE_DELETE(m_pSky);
	SAFE_DELETE(m_pTerrain);
	SAFE_DELETE(m_pPath);
}

HRESULT CFlyDemo::Load()
{
	// Load geometry
	if (FAILED(m_pSky->Load()))
		return E_FAIL;
	if (FAILED(m_pTerrain->Load()))
		return E_FAIL;
	
	// Load fly path
	m_pPath->Load("path.dat");
	m_bLoaded = TRUE;

	return S_OK;
}

HRESULT CFlyDemo::Init(LPDIRECT3DDEVICE7 pd3dDevice)
{
	HRESULT hr;

	pd3dDevice->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	pd3dDevice->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
	pd3dDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_SELECTARG1);
	pd3dDevice->SetTextureStageState(0, D3DTSS_MINFILTER, D3DTFN_LINEAR);
	pd3dDevice->SetTextureStageState(0, D3DTSS_MAGFILTER, D3DTFG_LINEAR);
	pd3dDevice->SetTextureStageState(0, D3DTSS_MIPFILTER, D3DTFP_LINEAR);
	pd3dDevice->SetTextureStageState(0, D3DTSS_ADDRESS, D3DTADDRESS_WRAP);

	pd3dDevice->SetRenderState(D3DRENDERSTATE_TEXTUREPERSPECTIVE, TRUE);
	pd3dDevice->SetRenderState(D3DRENDERSTATE_LIGHTING, FALSE);
	pd3dDevice->SetRenderState(D3DRENDERSTATE_DITHERENABLE, TRUE);
	pd3dDevice->SetRenderState(D3DRENDERSTATE_COLORVERTEX, TRUE);
	pd3dDevice->SetRenderState(D3DRENDERSTATE_SHADEMODE, D3DSHADE_GOURAUD);
	pd3dDevice->SetRenderState(D3DRENDERSTATE_ZENABLE, TRUE);
	pd3dDevice->SetRenderState(D3DRENDERSTATE_FILLMODE, D3DFILL_SOLID);

	hr = m_pSky->Init(pd3dDevice);
	if (FAILED(hr))
	{
		DD_ERR(hr);
		return E_FAIL;
	}

	hr = m_pTerrain->Init(pd3dDevice);
	if (FAILED(hr))
	{
		DD_ERR(hr);
		return E_FAIL;
	}

	m_bInitialized = TRUE;

	return S_OK;
}

VOID CFlyDemo::Destroy()
{
	m_bInitialized = FALSE;
	m_pSky->Destroy();
	m_pTerrain->Destroy();
}

HRESULT CFlyDemo::Render(FLOAT fTime, LPDIRECT3DDEVICE7 pd3dDevice)
{
	if ((m_bLoaded) && (m_bInitialized))
	{
		D3DXVECTOR3 v, vpos;
		D3DXQUATERNION q;

		// Calculate position
		m_pPath->Play(fTime, vpos, q);

		if (m_bWireframe)
		{
			pd3dDevice->SetRenderState(D3DRENDERSTATE_FILLMODE, D3DFILL_WIREFRAME);
			// Clear only when drawing wireframe to prevent overdraw
			//  use some weird color so wireframe stands out
			pd3dDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER,
				0x00FF00FF, 1.0f, 0);
		}

		// For sky rendering place viewer in the center of skydome
		v = D3DXVECTOR3(0.0f, vpos.y * 0.2f, 0.0f);
		g_Viewer.UpdateViewer(pd3dDevice, v, q);
		// Render sky
		m_pSky->Render(pd3dDevice);

		g_Viewer.UpdateViewer(pd3dDevice, vpos, q);
		// Render terrain
		m_pTerrain->Render(pd3dDevice);

		if (m_bWireframe)
			pd3dDevice->SetRenderState(D3DRENDERSTATE_FILLMODE, D3DFILL_SOLID);
	}

	return S_OK;
}

DWORD CFlyDemo::CountPolys()
{
	return m_pSky->CountPolys() + m_pTerrain->CountPolys();
}

FLOAT CFlyDemo::GetFlightTime()
{
	return m_pPath->GetPathTime();
}
