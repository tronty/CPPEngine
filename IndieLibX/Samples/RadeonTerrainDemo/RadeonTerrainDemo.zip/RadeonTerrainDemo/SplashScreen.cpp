//-----------------------------------------------------------------------------
// File: SplashScreen.cpp
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#define STRICT
#define D3D_OVERLOADS

#include "Helper.h"
#include "SplashScreen.h"
#include "Texture.h"
#include "TManager.h"
#include "DXErrors.h"


CSplashScreen::CSplashScreen() : CDemo()
{
	m_dwTexIndx = -1;
	m_bLoaded = FALSE;
	m_bInitialized = FALSE;
}

CSplashScreen::~CSplashScreen()
{
	DeleteTexture();
}

HRESULT CSplashScreen::Load()
{
	HRESULT hr;

	D3DVECTOR n = D3DVECTOR(0.0f, 0.0f, 1.0f);
    m_vMesh[0] = D3DVERTEX(D3DVECTOR(-1.0f,-1.0f, 0.0f), n, 1.0f, 1.0f);
    m_vMesh[1] = D3DVERTEX(D3DVECTOR(-1.0f, 1.0f, 0.0f), n, 1.0f, 0.0f);
    m_vMesh[2] = D3DVERTEX(D3DVECTOR( 1.0f,-1.0f, 0.0f), n, 0.0f, 1.0f);
    m_vMesh[3] = D3DVERTEX(D3DVECTOR( 1.0f, 1.0f, 0.0f), n, 0.0f, 0.0f);

	CTexture *pTexture = new CTexture();
	hr = pTexture->Create(_T("splash"), FALSE, FALSE);
	if (FAILED(hr))
	{
		SAFE_DELETE(pTexture);
		return E_FAIL;
	}
	m_dwTexIndx = g_TMan.AddTexture(pTexture);
	m_bLoaded = TRUE;

	return S_OK;
}

HRESULT CSplashScreen::Init(LPDIRECT3DDEVICE7 pd3dDevice)
{
	pd3dDevice->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	pd3dDevice->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_DIFFUSE);
	pd3dDevice->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_SELECTARG1);
	pd3dDevice->SetTextureStageState(0, D3DTSS_MINFILTER, D3DTFN_LINEAR);
	pd3dDevice->SetTextureStageState(0, D3DTSS_MAGFILTER, D3DTFG_LINEAR);
	pd3dDevice->SetTextureStageState(0, D3DTSS_MIPFILTER, D3DTFP_LINEAR);
	pd3dDevice->SetTextureStageState(0, D3DTSS_ADDRESS, D3DTADDRESS_WRAP);

	pd3dDevice->SetRenderState(D3DRENDERSTATE_SHADEMODE, D3DSHADE_GOURAUD);
	pd3dDevice->SetRenderState(D3DRENDERSTATE_DITHERENABLE, TRUE);
	pd3dDevice->SetRenderState(D3DRENDERSTATE_COLORVERTEX, TRUE);
	pd3dDevice->SetRenderState(D3DRENDERSTATE_CULLMODE, D3DCULL_NONE);
	pd3dDevice->SetRenderState(D3DRENDERSTATE_ZENABLE, TRUE);
	pd3dDevice->SetRenderState(D3DRENDERSTATE_ZWRITEENABLE, TRUE);
	pd3dDevice->SetRenderState(D3DRENDERSTATE_SPECULARENABLE, FALSE);
	pd3dDevice->SetRenderState(D3DRENDERSTATE_LOCALVIEWER, FALSE);
	pd3dDevice->SetRenderState(D3DRENDERSTATE_FOGENABLE, FALSE);

	D3DVIEWPORT7 vp;
	pd3dDevice->GetViewport(&vp);
	FLOAT fAspect = ((FLOAT)vp.dwHeight) / vp.dwWidth;

	// Load world transform
	D3DXMATRIX matWorld;
	D3DXMatrixIdentity(&matWorld);
	pd3dDevice->SetTransform(D3DTRANSFORMSTATE_WORLD, (D3DMATRIX*)matWorld);

	// Setup projection
	D3DXMATRIX matProj;
	D3DXMatrixPerspectiveFovLH(&matProj, PI / 3.0f, fAspect, 0.1f, 100.0f);
	pd3dDevice->SetTransform(D3DTRANSFORMSTATE_PROJECTION, (D3DMATRIX*)matProj);

	// Load view transform
	D3DXVECTOR3 vViewer = D3DVECTOR(0.0f, 0.0f, 2.0f);
	D3DXVECTOR3 vDir = D3DVECTOR(0.0f, 0.0f, -1.0f);
	D3DXVECTOR3 vUp = D3DVECTOR(0.0f, 1.0f, 0.0f);
	D3DXMATRIX matView;
	ComputeViewMatrix(&matView, &vViewer, &vDir, &vUp);
	pd3dDevice->SetTransform(D3DTRANSFORMSTATE_VIEW, (D3DMATRIX*)matView);

	m_bInitialized = TRUE;

	return S_OK;
}

VOID CSplashScreen::Destroy()
{
	m_bInitialized = FALSE;
}

HRESULT CSplashScreen::Render(FLOAT fTime, LPDIRECT3DDEVICE7 pd3dDevice)
{
	if ((m_bLoaded) && (m_bInitialized) && (m_dwTexIndx != -1))
	{
		CTexture *pTexture = g_TMan.GetTexture(m_dwTexIndx);
		if (pTexture != NULL)
		{
			pd3dDevice->SetTexture(0, pTexture->GetSurface());
			pd3dDevice->DrawPrimitive(D3DPT_TRIANGLESTRIP, D3DFVF_VERTEX, m_vMesh, 4, 0);
		}
		else
			pd3dDevice->SetTexture(0, NULL);
	}

	return S_OK;
}

VOID CSplashScreen::DeleteTexture()
{
	if (m_dwTexIndx != -1)
	{
		g_TMan.DeleteTexture(m_dwTexIndx);
		m_dwTexIndx = -1;
	}
}
