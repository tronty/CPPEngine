//-----------------------------------------------------------------------------
// File: VertexStore.cpp
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#define STRICT
#define D3D_OVERLOADS

#include <tchar.h>
#include <stdio.h>
#include "Helper.h"
#include "VertexStore.h"
#include "DXErrors.h"

CVertexStore::CVertexStore(FILE *fp)
{
	fread(&m_dwVBCount, sizeof(DWORD), 1, fp);

	m_pVB = new VB[m_dwVBCount];
	for(DWORD i = 0; i < m_dwVBCount; i++)
	{
		fread(&m_pVB[i].dwSize, sizeof(DWORD), 1, fp);
		m_pVB[i].pVertices = new LITVERTEX[m_pVB[i].dwSize];
		fread(m_pVB[i].pVertices, sizeof(LITVERTEX), m_pVB[i].dwSize, fp);
		m_pVB[i].pVB = NULL;
	}
}

CVertexStore::~CVertexStore()
{
	for(DWORD i = 0; i < m_dwVBCount; i++)
	{
		SAFE_DELETE_ARRAY(m_pVB[i].pVertices);
	}
	SAFE_DELETE_ARRAY(m_pVB);
}

HRESULT CVertexStore::Init(LPDIRECT3DDEVICE7 pd3dDevice)
{
	for(DWORD i = 0; i < m_dwVBCount; i++)
	{
		if (m_pVB[i].pVB == NULL)
		{
			SAFE_RELEASE(m_pVB[i].pVB);

			D3DVERTEXBUFFERDESC vbDesc;
			ZeroMemory(&vbDesc, sizeof(D3DVERTEXBUFFERDESC));
			vbDesc.dwSize = sizeof(D3DVERTEXBUFFERDESC);
			vbDesc.dwCaps = D3DVBCAPS_WRITEONLY;
			vbDesc.dwFVF = D3DFVF_LVERTEX1;
			vbDesc.dwNumVertices = m_pVB[i].dwSize;

			D3DDEVICEDESC7 ddDesc;
			if (FAILED(pd3dDevice->GetCaps(&ddDesc)))
				return E_FAIL;

			if (!IsEqualIID(ddDesc.deviceGUID, IID_IDirect3DTnLHalDevice))
				vbDesc.dwCaps |= D3DVBCAPS_SYSTEMMEMORY;

			LPDIRECT3D7 pD3D;
			pd3dDevice->GetDirect3D(&pD3D);

			if (FAILED(pD3D->CreateVertexBuffer(&vbDesc, &m_pVB[i].pVB, 0L)))
			{
				pD3D->Release();
				return E_FAIL;
			}
			pD3D->Release();
		}

		LPLITVERTEX pvbVertices;
		if (SUCCEEDED(m_pVB[i].pVB->Lock(DDLOCK_WAIT, (VOID**)&pvbVertices, NULL)))
		{
			memcpy(pvbVertices, m_pVB[i].pVertices, m_pVB[i].dwSize * sizeof(LITVERTEX));
			m_pVB[i].pVB->Unlock();
			m_pVB[i].pVB->Optimize(pd3dDevice, 0);
		}
		else
			return E_FAIL;
	}

	return S_OK;
}

VOID CVertexStore::Destroy()
{
	for(DWORD i = 0; i < m_dwVBCount; i++)
	{
		SAFE_RELEASE(m_pVB[i].pVB);
	}
}

LPDIRECT3DVERTEXBUFFER7 CVertexStore::GetVertexBuffer(DWORD index, DWORD *size)
{
	if (index < m_dwVBCount)
	{
		*size = m_pVB[index].dwSize; 
		return m_pVB[index].pVB;
	}
	else
		return NULL;
}
