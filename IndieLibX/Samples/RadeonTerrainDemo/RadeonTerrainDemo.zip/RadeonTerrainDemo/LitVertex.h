//-----------------------------------------------------------------------------
// File: LitVertex.h
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#ifndef _LITVERTEX_H
#define _LITVERTEX_H

#include <d3dx.h>

// Prelit vertex with one set of texture coordinates
#define D3DFVF_LVERTEX1 (D3DFVF_XYZ | D3DFVF_DIFFUSE |D3DFVF_TEX1)

typedef struct _LITVERTEX 
{
	float x, y, z;
	D3DCOLOR color;
	float tu, tv;
#if (defined __cplusplus) && (defined D3D_OVERLOADS)
	_LITVERTEX() { }
	_LITVERTEX(const D3DXVECTOR3& v, D3DCOLOR _color, float _tu, float _tv)
	{ 
		x = v.x; y = v.y; z = v.z;
		color = _color; tu = _tu; tv = _tv;
	}
#endif
} LITVERTEX, *LPLITVERTEX; 

#endif
