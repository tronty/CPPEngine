//-----------------------------------------------------------------------------
// File: TriangleList.cpp
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#define STRICT
#define D3D_OVERLOADS

#include <tchar.h>
#include <stdio.h>
#include <math.h>
#include "Helper.h"
#include "TriangleList.h"
#include "DXErrors.h"


CTriangleList::CTriangleList()
{
	m_pIndices = NULL;
	m_dwMaterialID = -1;
}

CTriangleList::CTriangleList(FILE *fp)
{
	m_pIndices = NULL;
	m_dwMaterialID = -1;

	Load(fp);
}

CTriangleList::~CTriangleList()
{
	DeleteArrays();
}

VOID CTriangleList::DeleteArrays()
{
	if (m_pIndices != NULL)
	{
		delete []m_pIndices;
		m_pIndices = NULL;
	}
}

HRESULT CTriangleList::Load(FILE *fp)
{
	DeleteArrays();

	fread(&m_dwMaterialID, sizeof(DWORD), 1, fp);
	fread(&m_dwIndNum, sizeof(DWORD), 1, fp);
	fread(&m_dwVBID, sizeof(DWORD), 1, fp);

	m_pIndices = new WORD[m_dwIndNum];
	fread(m_pIndices, sizeof(WORD), m_dwIndNum, fp);

	return S_OK;
}

HRESULT CTriangleList::Render(LPDIRECT3DDEVICE7 pd3dDevice, CVertexStore *pVS)
{
	DWORD size;
	LPDIRECT3DVERTEXBUFFER7 pVB;

	pVB = pVS->GetVertexBuffer(m_dwVBID, &size);
	pd3dDevice->DrawIndexedPrimitiveVB(D3DPT_TRIANGLELIST,
		pVB, 0, size, m_pIndices, m_dwIndNum, 0);

	return S_OK;
}
