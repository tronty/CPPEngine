//-----------------------------------------------------------------------------
// File: TriangleList.h
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#ifndef _TRIANGLELIST_H
#define _TRIANGLELIST_H

#include <d3dx.h>
#include "LitVertex.h"
#include "VertexStore.h"

class CTriangleList
{
	VOID DeleteArrays();

public:
	DWORD m_dwMaterialID;
	WORD *m_pIndices;
	DWORD m_dwIndNum;
	DWORD m_dwVBID;

	CTriangleList();
	CTriangleList(FILE *fp);
	~CTriangleList();
	HRESULT Load(FILE *fp);
	HRESULT Render(LPDIRECT3DDEVICE7 pd3dDevice, CVertexStore *pVS);
};

#endif
