//-----------------------------------------------------------------------------
// File: RenderQueue.h
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#ifndef _RENDERQUEUE_H
#define _RENDERQUEUE_H

#include <d3dx.h>
#include "MManager.h"
#include "TriangleList.h"

#define MAX_QUEUES MAX_MATERIALS
#define MAX_VB_QUEUES 10
// Maximum number of triangle lists in a single queue
#define MAX_QUEUE_SIZE 1000

typedef struct tagQUEUE
{
	DWORD dwVBID;
	CTriangleList **pLists;
	DWORD dwListCount;
} QUEUE;

class CRenderQueue
{
	QUEUE m_Queues[MAX_MATERIALS][MAX_VB_QUEUES];
	DWORD m_dwVBQueueCount[MAX_MATERIALS];

public:
	CRenderQueue();
	~CRenderQueue();
	HRESULT Init(LPDIRECT3DDEVICE7 pd3dDevice);
	VOID Destroy();
	VOID ClearQueue();
	HRESULT AddToQueue(CTriangleList *tlist);
	HRESULT Render(LPDIRECT3DDEVICE7 pd3dDevice, CVertexStore *pVS);
	DWORD CountPolys();
};

#endif
