//-----------------------------------------------------------------------------
// File: Texture.cpp
//
//  Terrain Demo.
//
// Copyright (c) 2000 ATI Technologies Inc. All rights reserved.
//-----------------------------------------------------------------------------

#define STRICT
#define D3D_OVERLOADS

#include <tchar.h>
#include <stdio.h>
#include "Helper.h"
#include "Texture.h"
#include "DXErrors.h"

CTexture::CTexture()
{
	m_pddsSurface = NULL;
}

CTexture::~CTexture()
{
}

HRESULT CTexture::Create(TCHAR *strTexName, BOOL bMipMap, BOOL bAlpha)
{
	m_bMipMap = bMipMap;
	m_bHasAlpha = bAlpha;
	_stprintf(m_strFileName, _T("%s%s.bmp"), TEXTURE_PATH, strTexName);

	return S_OK;
}

HRESULT CTexture::Restore(LPDIRECT3DDEVICE7 pd3dDevice)
{
	HRESULT hr;
	DWORD dwFlags;
	D3DX_SURFACEFORMAT sf;

	if (m_bMipMap)
		dwFlags = NULL;
	else
		dwFlags = D3DX_TEXTURE_NOMIPMAP;

	sf = D3DX_SF_A8R8G8B8;

	hr = D3DXCreateTextureFromFile(pd3dDevice,
		&dwFlags,
		0,
		0,
		&sf,
		NULL,
		&m_pddsSurface,
		NULL,
		m_strFileName,
		D3DX_FT_LINEAR);
	if (FAILED(hr))
	{
		DD_ERR(hr);
		return E_FAIL;
	}

	return S_OK;
}

VOID CTexture::Invalidate()
{
	SAFE_RELEASE(m_pddsSurface);
}

LPDIRECTDRAWSURFACE7 CTexture::GetSurface() 
{ 
	return m_pddsSurface; 
}
