
GLuint setShaders( const char *vert_source, const char * frag_source );
void checkShaderExt( void );

